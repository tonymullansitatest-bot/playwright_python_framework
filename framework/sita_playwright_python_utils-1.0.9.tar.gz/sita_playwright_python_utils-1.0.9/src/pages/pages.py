"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
from src.pages.excel_page import ExcelPage
from src.pages.gherkin_examples_page import GherkinExamplesPage
from src.pages.my_bag_page import MyBaGPage


class Pages:

    def __init__(self, context):
        self.gherkin_examples_page = GherkinExamplesPage(context.page)
        self.my_bag_page = MyBaGPage(context.page)
        self.my_excel_page = ExcelPage(context.page)

