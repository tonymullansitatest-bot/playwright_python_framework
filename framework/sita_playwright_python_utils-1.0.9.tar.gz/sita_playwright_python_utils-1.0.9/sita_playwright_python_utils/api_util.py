"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import json
import logging

from playwright.async_api import APIRequestContext, APIResponse
from pathlib import Path

from sita_playwright_python_utils.ApiUtil import logger


class ApiUtil:

    @staticmethod
    async def get(url: str, api_request: APIRequestContext, headers: dict = None, params: dict = None,
                  ignore_https=False) -> APIResponse:
        """
        Sends an asynchronous HTTP GET request.

        Args:
            url (str): The URL to send the GET request to.
            api_request (APIRequestContext): The API request context containing necessary request details.
            headers (dict, optional): A dictionary of HTTP headers to send with the request.
            params (dict, optional): A dictionary of query parameters to send with the request.
            ignore_https (bool, optional): Flag to ignore SSL certificate validation (default is False).

        Returns:
            APIResponse: The response object returned from the GET request.

        Raises:
            Exception: If the GET request fails due to network issues or other errors.
        """
        try:
            logger.log(f"URL: {url}")
            response = await api_request.get(url, headers=headers, params=params, ignore_https_errors=ignore_https)
            logger.log(f"[API-GET] Response Status: {response.status}")
            return response
        except Exception as e:
            logger.log(f"[API-GET] Failed to make GET request: {str(e)}", log_level=logging.ERROR)
            raise

    @staticmethod
    async def post(url: str, api_request: APIRequestContext, payload: dict = None, headers: dict = None,
                   params: dict = None, ignore_https=False) -> APIResponse:
        """
        Sends an asynchronous HTTP POST request.

        Args:
            url (str): The URL to send the POST request to.
            api_request (APIRequestContext): The API request context containing necessary request details.
            payload (dict, optional): Data to send in the request body as JSON.
            headers (dict, optional): A dictionary of HTTP headers to send with the request.
            params (dict, optional): A dictionary of query parameters to send with the request.
            ignore_https (bool, optional): Flag to ignore SSL certificate validation.

        Returns:
            APIResponse: The response object returned from the POST request.

        Raises:
            Exception: If the POST request fails due to network issues or other errors.
        """
        try:
            logger.log(f"URL: {url}")
            response = await api_request.post(
                url,
                data=json.dumps(payload) if payload else None,
                headers=headers,
                params=params,
                ignore_https_errors=ignore_https
            )
            logger.log(f"[API-POST] Response Status: {response.status}")
            return response
        except Exception as e:
            logger.log(f"[API-POST] Failed to make POST request: {str(e)}", log_level=logging.ERROR)
            raise

    @staticmethod
    async def put(url: str, api_request: APIRequestContext, payload: dict = None, headers: dict = None,
                  params: dict = None, ignore_https=False) -> APIResponse:
        """
        Sends an asynchronous HTTP PUT request.

        Args:
            url (str): The URL to send the PUT request to.
            api_request (APIRequestContext): The API request context containing necessary request details.
            payload (dict, optional): Data to send in the request body as JSON.
            headers (dict, optional): A dictionary of HTTP headers to send with the request.
            params (dict, optional): A dictionary of query parameters to send with the request.
            ignore_https (bool, optional): Flag to ignore SSL certificate validation.

        Returns:
            APIResponse: The response object returned from the PUT request.

        Raises:
            Exception: If the PUT request fails due to network issues or other errors.
        """
        try:
            logger.log(f"URL: {url}")
            response = await api_request.put(
                url,
                data=json.dumps(payload) if payload else None,
                headers=headers,
                params=params,
                ignore_https_errors=ignore_https
            )
            logger.log(f"[API-PUT] Response Status: {response.status}")
            return response
        except Exception as e:
            logger.log(f"[API-PUT] Failed to make PUT request: {str(e)}", log_level=logging.ERROR)
            raise

    @staticmethod
    async def patch(url: str, api_request: APIRequestContext, payload: dict = None, headers: dict = None,
                    params: dict = None, ignore_https=False) -> APIResponse:
        """
        Sends an asynchronous HTTP PATCH request.

        Args:
            url (str): The URL to send the PATCH request to.
            api_request (APIRequestContext): The API request context containing necessary request details.
            payload (dict, optional): Data to send in the request body as JSON.
            headers (dict, optional): A dictionary of HTTP headers to send with the request.
            params (dict, optional): A dictionary of query parameters to send with the request.
            ignore_https (bool, optional): Flag to ignore SSL certificate validation.

        Returns:
            APIResponse: The response object returned from the PATCH request.

        Raises:
            Exception: If the PATCH request fails due to network issues or other errors.
        """
        try:
            logger.log(f"URL: {url}")
            response = await api_request.patch(
                url,
                data=json.dumps(payload) if payload else None,
                headers=headers,
                params=params,
                ignore_https_errors=ignore_https
            )
            logger.log(f"[API-PATCH] Response Status: {response.status}")
            return response
        except Exception as e:
            logger.log(f"[API-PATCH] Failed to make PATCH request: {str(e)}", log_level=logging.ERROR)
            raise

    @staticmethod
    async def delete(url: str, api_request: APIRequestContext, headers: dict = None, params: dict = None,
                     ignore_https=False) -> APIResponse:
        """
        Sends an asynchronous HTTP DELETE request.

        Args:
            url (str): The URL to send the DELETE request to.
            api_request (APIRequestContext): The API request context containing necessary request details.
            headers (dict, optional): A dictionary of HTTP headers to send with the request.
            params (dict, optional): A dictionary of query parameters to send with the request.
            ignore_https (bool, optional): Flag to ignore SSL certificate validation.

        Returns:
            APIResponse: The response object returned from the DELETE request.

        Raises:
            Exception: If the DELETE request fails due to network issues or other errors.
        """
        try:
            logger.log(f"URL: {url}")
            response = await api_request.delete(url, headers=headers, params=params, ignore_https_errors=ignore_https)
            logger.log(f"[API-DELETE] Response Status: {response.status}")
            return response
        except Exception as e:
            logger.log(f"[API-DELETE] Failed to make DELETE request: {str(e)}", log_level=logging.ERROR)
            raise

    @staticmethod
    async def parse_api_response_json(response: APIResponse) -> dict:
        """
        Attempts to parse the response body as JSON.

        Args:
            response (APIResponse): The API response object to parse.

        Returns:
            dict: The parsed JSON data.

        Raises:
            Exception: If parsing fails, returns the raw response text instead.
        """
        try:
            body = await response.json()
            return body
        except Exception as e:
            logger.log(f"[API-RESPONSE] Failed to parse response JSON: {str(e)}", log_level=logging.ERROR)
            text = await response.text()
            logger.log("[API-RESPONSE] Returning raw response text due to parsing failure")
            return {"text": text}

    @staticmethod
    async def validate_status(response: APIResponse, expected_status: int):
        """
        Validates the HTTP status code of the response.

        Args:
            response (APIResponse): The response object to validate.
            expected_status (int): The expected HTTP status code.

        Raises:
            AssertionError: If the response status does not match the expected status.
        """
        try:
            actual_status = response.status
            logger.log(f"Expected Status: {expected_status}")
            logger.log(f"Actual Status: {actual_status}")

            assert actual_status == expected_status, f"Expected {expected_status}, got {actual_status}"

            logger.log("[API-VALIDATION] Status validation passed")
        except AssertionError as e:
            logger.log(f"[API-VALIDATION] Assertion error: {str(e)}", log_level=logging.ERROR)
            raise e

    @staticmethod
    async def validate_keys(response: APIResponse, expected_keys: list):
        """
        Checks that the expected keys are present in the response JSON body.

        Args:
            response (APIResponse): The response object to validate.
            expected_keys (list): A list of keys expected in the response.

        Raises:
            AssertionError: If any expected keys are missing from the response body.
        """
        try:
            body = await ApiUtil.parse_api_response_json(response)
            missing_keys = [key for key in expected_keys if key not in body]

            if missing_keys:
                logger.log(f"[API-VALIDATION] Missing keys in response: {missing_keys}", log_level=logging.ERROR)
                raise AssertionError(f"Missing keys: {', '.join(missing_keys)}")

            logger.log(f"[API-VALIDATION] All expected keys are present: {expected_keys}")
        except Exception as e:
            logger.log(f"[API-VALIDATION] Failed to validate response keys: {str(e)}", log_level=logging.ERROR)
            raise e

    @staticmethod
    def load_payload(file_name: str, dynamic_data: dict = None) -> dict:
        """
        Loads a JSON payload from a file and applies dynamic data if provided.

        Args:
            file_name (str): The name of the JSON file to load.
            dynamic_data (dict, optional): A dictionary of data to apply to the loaded payload.

        Returns:
            dict: The final payload after applying dynamic data (if any).

        Raises:
            Exception: If the payload fails to load or apply dynamic data.
        """
        try:
            path = Path("data") / file_name
            logger.log(f"[PAYLOAD] Resolved path: {path}")
            with open(path, "r") as f:
                payload = json.load(f)
            logger.log(f"[PAYLOAD] Original Payload: {json.dumps(payload, indent=2)}")

            if dynamic_data:
                logger.log(f"[PAYLOAD] Applying dynamic data: {json.dumps(dynamic_data, indent=2)}")
                payload = json.loads(json.dumps(payload).format(**dynamic_data))

            logger.log(f"[PAYLOAD] Final Payload after dynamic replacement: {json.dumps(payload, indent=2)}")
            return payload
        except Exception as e:
            logger.log(f"[PAYLOAD] Failed to load payload: {str(e)}", log_level=logging.ERROR)
            raise e

