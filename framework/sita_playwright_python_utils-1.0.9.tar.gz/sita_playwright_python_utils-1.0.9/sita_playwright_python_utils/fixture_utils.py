"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import os
import logging
from tkinter import Tk

import allure
from allure_commons.types import AttachmentType

from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework fixture_utils", log_level=logging.INFO)


def file_naming_convention(scenario):
    """
    Generate a file name based on the scenario name.

    Args:
        scenario: The scenario object containing information about the current test scenario.

    Returns:
        str: The generated file name.
    """
    test_id = scenario.name.split("-")[0].strip()
    return test_id


def set_environment(context):
    """
    Set the environment URL based on the configuration.

    Returns:
        str: The URL of the environment.
    """
    if 'environment' not in context.config.userdata:
        raise ValueError("No environment specified. Please provide an environment : \"\" in the behave.ini file.")

    env = context.config.userdata['environment']
    url = context.config.userdata[env]
    return url


def set_desktop_screen_size():
    """
    Set the screen size for desktop browsers.

    Returns:
        tuple: The width and height of the screen.
    """
    screen_width = config_ini.get_int("BROWSER", "VIEWPORT_WIDTH")
    screen_height = config_ini.get_int("BROWSER", "VIEWPORT_HEIGHT")

    if screen_width == 0 and screen_height == 0:
        root = Tk()
        root.withdraw()  # Prevent the Tkinter window from appearing
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
    return screen_width, screen_height


def choose_browser(context):
    """
    Choose the browser based on the configuration.

    Returns:
        str: The name of the browser.
    """
    browser = context.config.userdata['browser']
    if browser == "firefox":
        return browser
    elif browser == "safari":
        browser = "webkit"
    elif browser == "edge" or browser == "chrome" or browser == "chromium":
        browser = "chromium"
    else:
        raise Exception("Invalid browser name")
    return browser


def choose_channel(context):
    """
    Choose the browser channel based on the configuration.

    Returns:
        str: The name of the browser channel.
    """
    browser = context.config.userdata['browser']
    return "msedge" if browser == "edge" else "chrome" if browser == "chrome" else None


async def start_tracing(context):
    """
    Start tracing with the configured settings.

    Args:
        context: Behave context object for sharing data.
    """
    # Only start tracing if browser_context exists (i.e., in UI or Hybrid mode)
    if hasattr(context, "browser_context"):
        logger.log(f"Enable tracing screenshots: {config_ini.get_boolean('DEBUG', 'ENABLE_TRACING_SCREENSHOTS')}")
        logger.log(f"Enable tracing snapshots: {config_ini.get_boolean('DEBUG', 'ENABLE_TRACING_SNAPSHOTS')}")
        logger.log(f"Enable tracing sources: {config_ini.get_boolean('DEBUG', 'ENABLE_TRACING_SOURCES')}")

        await context.browser_context.tracing.start(
            screenshots=config_ini.get_boolean('DEBUG', 'ENABLE_TRACING_SCREENSHOTS'),
            snapshots=config_ini.get_boolean('DEBUG', 'ENABLE_TRACING_SNAPSHOTS'),
            sources=config_ini.get_boolean('DEBUG', 'ENABLE_TRACING_SOURCES')
        )


async def stop_tracing(context, scenario):
    """
    Stop tracing and save the trace file.

    Args:
        context: Behave context object for sharing data.
        scenario: The scenario object containing information about the current test scenario.
    """
    # Only stop tracing if browser_context exists
    if hasattr(context, "browser_context"):
        trace_path = f"{config_ini.get('PATHS', 'TRACE_DIR')}{file_naming_convention(scenario)}.zip"
        await context.browser_context.tracing.stop(path=trace_path)


async def attach_screenshot_if_failed(context, scenario):
    """
    Attach a screenshot to the allure report if the scenario failed.

    Args:
        context: Behave context object for sharing data.
        scenario: The scenario object containing information about the current test scenario.
    """
    if hasattr(context, "page"):
        screenshot = await context.page.screenshot(
            path=config_ini.get('PATHS', 'SCREENSHOT_DIR') + f"/{file_naming_convention(scenario)}.{config_ini.get('DATA TYPES', 'SCREENSHOT_TYPE')}")
        allure.attach(screenshot, name=file_naming_convention(scenario),
                      attachment_type=AttachmentType.JPG)

async def rename_video_file(context, scenario):
    """
    Rename the video file with scenario details.

    Args:
        context: Behave context object for sharing data.
        scenario: The scenario object containing information about the current test scenario.
    """
    video_file_path = await context.page.video.path()
    video_dir = config_ini.get('PATHS', 'VIDEO_DIR')

    # Ensure the directory exists
    os.makedirs(video_dir, exist_ok=True)

    new_name = os.path.join(config_ini.get('PATHS', 'VIDEO_DIR'), f"{file_naming_convention(scenario)}.webm")
    if os.path.exists(new_name):
        os.remove(new_name)
    os.rename(video_file_path, new_name)
