"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import logging
from sita_playwright_python_utils import JsonUtil
import requests
import urllib3

import json
import ssl

from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework api_util", log_level=logging.INFO)

json_util = JsonUtil

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def session_auth():
    """
    @purpose Function provides user session authentication
    """
    #my_session = requests.session()
    #my_session.auth = (configurations.get_user(), configurations.get_password)


def send_cookie(url_value, my_cookie: dict):
    """
    @purpose Function used to send cookies with input request
    @param url_value
    @param my_cookie: a dictionary type parameter that we use to send cookie values
    """
    logger.log('Cookie is being sent.')
    try:
        response = requests.get(url_value, allow_redirects=True, cookies=my_cookie)
        logger.log('The response code is :' + str(response.status_code))
        if str(my_cookie) in response.text:
            logger.log('The cookies i sent were successfully received.')
        return response
    except requests.RequestException:
        logger.log('Send cookie request has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def put_request_with_data(**kwargs):
    response = requests.put(url=kwargs['url'], headers=kwargs['headers'], auth=(kwargs['auth']),
                            data=json.dumps(kwargs['data']), verify=ssl.CERT_NONE)
    logger.log('Response code is: ' + str(response.status_code))
    if response.status_code != 200:
        logger.log('Error in put_request_with_data(): ' + response.text, log_level=logging.WARNING)
        raise requests.exceptions.RequestException('Error in put_request_with_data().')
    return response.json()

def put_request_with_data_and_params(**kwargs):
    # Making the PUT request using session-based headers
    response = requests.put(
        url=kwargs['url'],
        headers=kwargs['headers'],
        data=kwargs['data'],
        params=kwargs['params'],
        verify=ssl.CERT_NONE
    )

    if response.status_code != 200:
        logger.log(f'Error in put_request_with_data_and_params(). Status Code: {response.status_code}', log_level=logging.WARNING)
        logger.log(f"Response Body: {response.text}")
        raise requests.exceptions.RequestException('Error in put_request_with_data_and_params().')

    return response.json()

def post_request_with_data(**kwargs):
    response = requests.post(url=kwargs['url'], headers=kwargs['headers'],
                              data=kwargs['data'],verify=ssl.CERT_NONE)
    logger.log(response)
    if response.status_code != 201:
        logger.log('Error in post_request_with_data():' + response.text, log_level=logging.WARNING)
        raise requests.exceptions.RequestException('Error in post_request_with_data().')
    return response.json()

def get_request_with_kwargs(**kwargs):
    try:
        response = requests.get(url=kwargs['url'],headers=kwargs['headers'],params=kwargs['params'],verify=ssl.CERT_NONE
        )

        if response.status_code != 200:
            logger.log('Error in get_request_with_kwargs(): ' + response.text, log_level=logging.WARNING)
            raise requests.exceptions.RequestException('Error in get_request_with_kwargs()')

        return response.json()

    except requests.exceptions.RequestException as e:
        logger.log(f"Request failed: {e}", log_level=logging.WARNING)
        raise


def get_request(my_url):
    """
    @purpose Get request function.
    @param my_url : the url needed for the get request
    """
    try:
        my_request = requests.get(my_url)
        logger.log(my_request.json())
        return my_request
    except requests.RequestException:
        logger.log('Get request has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def get_request_with_params(base_url, params: dict):
    """
    @purpose Method to get api request with custom headers
    @param base_url
    @param params : dictionary of parameters
    """
    logger.log("Creating api request with parameters")
    try:
        response = requests.get(base_url, params=params)
        logger.log('The response code for the get request is :' + str(response.status_code))
        return response
    except requests.RequestException:
        logger.log('Get request with params has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def get_request_with_auth(url, auth_username: str, password: str):
    """
    @purpose Get request function with user authentication
    @param url the url of the request
    @param auth_username : auth=('username','password')
    """
    try:
        response = requests.get(url, auth=(auth_username, password))
        logger.log('The response code for the get request is :' + str(response.status_code))
    except requests.RequestException:
        logger.log('Get request with auth has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def post_request(my_url):
    """
    @purpose Post request function
    """
    try:
        response = requests.post(my_url)
        logger.log('The response code for the post request is :' + str(response.status_code))
        logger.log(response)
        return response
    except requests.RequestException:
        logger.log('Post request function has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def post_request_with_headers(base_url, my_headers: dict, expected_status_code):
    """
    @purpose  Method to post api request with  custom header
              r = requests.post('https://httpbin.org/post', data = {'key':'value'})
              header = {'user-agent':'my-app/0.0.1'}
              r = requests.get(base_url, header)

    @param base_url
    @param my_headers : dictionary of header value
    @param expected_status_code : the expected status code e.g. 200
    @return dictionary of the response values
    """
    try:
        response = requests.post(base_url, headers=my_headers)
        logger.log('The response code for the post request is :' + str(response.status_code))
        logger.log(response)
        if response.status_code == expected_status_code:
            return response
    except requests.RequestException:
        logger.log('Post request with headers function has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def post_request_with_json(my_url, my_json):
    """
    @purpose Post request function that takes json parameter
    @params my_url
    @params my_json : example payload = {'airline' : 'Blue', 'airport' : 'LAX'}   -> Content-Type: application/json
    """
    try:
        my_request = requests.post(my_url, json=my_json)
        return my_request
    except requests.RequestException:
        logger.log('Post request with json function has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def post_request_with_form_data(my_url, payload):
    """
    @purpose Post request used for form data
    @params my_url
    @params payload: add form data here. payload = {'airline' : 'Blue', 'airport' : 'LAX'}
    """
    try:
        my_request = requests.post(my_url, data=payload)
        return my_request
    except requests.RequestException:
        logger.log('Post request with form data has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def put_request(my_url):
    """
    @purpose Put request function
    @params my_url : url used to make the put request
    """
    try:
        response = requests.put(my_url)
        logger.log('The response code for the put request is :' + str(response.status_code))
        logger.log(response)
        return response
    except requests.RequestException:
        logger.log('Put request function has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def patch_request(my_url):
    """
    @purpose         Patch request function
    @params my_url : url used to make the patch
    """
    try:
        response = requests.patch(my_url)
        logger.log('The response code for the patch request is :' + str(response.status_code))
        return response
    except requests.RequestException:
        logger.log('Patch request function has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def delete_request(my_url):
    """
    @purpose          Delete request function
    @params my_url : url used to make the delete request
    """
    try:
        response = requests.delete(my_url)
        logger.log('The response code for the delete request is :' + str(response.status_code))
        logger.log(response.text)
        return response
    except requests.RequestException:
        logger.log('Delete request function has raised an exception:', log_level=logging.WARNING)


def save_image(image_url):
    """
    @purpose           Function downloads image locally
    @param image_url : the location of the image on server
    """
    try:
        r = requests.get(image_url)
        if r.status_code == 200:
            with open('image.jpg', 'wb') as fd:
                for chunk in r.iter_content(chunk_size=500):
                    fd.write(chunk)
                return fd
    except requests.RequestException:
        logger.log('Save image function has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def send_attachments(my_url, my_file):
    """
    @purpose   Post with attachment.
               Returns the status code
    @param my_url
    @param my_file : File path and file name is needed, example: 'C:\\Users\\Me\\Documents\\mydata.cvs'
    """
    try:
        work_file = {'file': open(my_file, 'rb')}
        my_request = requests.post(my_url, files=work_file)
        logger.log('The response code is :' + str(my_request.status_code))
        return my_request
    except requests.RequestException:
        logger.log('Send attachments has raised an exception:', log_level=logging.WARNING)
        logger.log(requests.RequestException.response, log_level=logging.WARNING)


def put_request_with_params(**kwargs):
    response = requests.put(url=kwargs['url'],headers=kwargs['headers'], params=kwargs['params'], verify=ssl.CERT_NONE
    )

    if response.status_code != 200:
        logger.log(f'Error in put_request_with_params. Status Code: {response.status_code}', log_level=logging.WARNING)
        logger.log(f"Response Body: {response.text}")
        raise requests.exceptions.RequestException('Error in put_request_with_params.')

    return response.json()


def post_request_with_files(**kwargs):
    """
    @purpose    Generic POST API for multipart file upload
    """

    response = requests.post(
        url=kwargs['url'],
        headers=kwargs['headers'],
        files=kwargs['files'],
        params=kwargs.get('params'),
        verify=ssl.CERT_NONE
    )

    logger.log(response)

    if response.status_code != 201:
        logger.log(
            'Error in post_request_with_files(): ' + response.text,
            log_level=logging.WARNING
        )
        raise requests.exceptions.RequestException(
            'Error in post_request_with_files().'
        )

    return response