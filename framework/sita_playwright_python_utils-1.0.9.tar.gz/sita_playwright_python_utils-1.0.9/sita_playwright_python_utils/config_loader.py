"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import configparser
import os
import logging

from sita_playwright_python_utils.logger import Logger

# Initialize custom Logger
logger = Logger(log_dir="debug/logs/", log_name="framework config_loader", log_level=logging.INFO)


class ConfigLoader:
    """Handles loading and validating configuration from .ini files."""

    def __init__(self, default_file, user_file, required_structure):
        self.config = configparser.ConfigParser(interpolation=None)

        # Resolve paths
        self.base_dir = os.path.dirname(os.path.abspath(__file__))  # Package directory
        self.default_path = os.path.join(self.base_dir, default_file)
        self.user_path = os.path.expanduser(user_file)  # User config in home directory

        self.required_structure = required_structure

        # Load configurations in order of priority
        self.load_configs()
        # Validate the final configuration
        self.validate_config()

    def load_configs(self):
        """Load configurations with priority: Default < User"""
        if os.path.exists(self.user_path):
            # Load user config if exists
            try:
                self.config.read(self.user_path)
                logger.log(f"Loaded user configuration from {self.user_path}", logging.INFO)
            except configparser.Error as e:
                logger.log(f"Warning: Error reading user config file {self.user_path}: {e}", logging.WARNING)
        else:
            # Load default config if user config does not exist
            self.config.read(self.default_path)
            logger.log(f"Loaded default configuration from {self.default_path}", logging.INFO)

    def validate_config(self):
        """Ensure all required sections and keys are present."""

        for section, keys in self.required_structure.items():
            if not self.config.has_section(section):
                logger.log(f"Warning: Missing section [{section}]. Adding default values.", logging.WARNING)
                self.config.add_section(section)

            for key in keys:
                if not self.config.has_option(section, key):
                    default_value = self.get_default_value(section, key)  # Get default value
                    self.config.set(section, key, default_value)  # Set default value
                    logger.log(
                        f"Warning: Missing key '{key}' in [{section}]. Using default value: {default_value}"
                        , logging.WARNING
                    )  # Print used value

    def get_default_value(self, section, key):
        """Return default values based on the default config."""
        default_config = configparser.ConfigParser(interpolation=None)
        default_config.read(self.default_path)
        return default_config.get(section, key, fallback="")  # Fallback to empty string if not found

    def get(self, section, key, fallback=None):
        """Get a configuration value with an optional fallback."""
        try:
            return self.config.get(section, key, fallback=fallback)
        except configparser.NoOptionError:
            logger.log(f"Warning: Missing key '{key}' in [{section}]. Using fallback '{fallback}'.", logging.WARNING)
            return fallback

    def get_int(self, section, key, fallback=None):
        """Get an integer configuration value."""
        try:
            return self.config.getint(section, key, fallback=fallback)
        except ValueError:
            logger.log(f"Warning: Invalid integer for key '{key}' in [{section}]. Using fallback {fallback}.",
                       logging.WARNING)
            return fallback

    def get_boolean(self, section, key, fallback=False):
        """Get a boolean configuration value."""
        try:
            return self.config.getboolean(section, key, fallback=fallback)
        except ValueError:
            logger.log(f"Warning: Invalid boolean for key '{key}' in [{section}]. Using fallback {fallback}.",
                       logging.WARNING)
            return fallback


# Create a globally accessible config instance
config_required_structure = {
    "MOBILE": ["MOBILE_DEVICE_MODEL"],
    "BROWSER": ["HEADLESS", "VIEWPORT_WIDTH", "VIEWPORT_HEIGHT", "IGNORE_HTTP_ERRORS"],
    "DEBUG": ["ENABLE_RECORDING", "ENABLE_TRACING", "ENABLE_TRACING_SCREENSHOTS", "ENABLE_TRACING_SNAPSHOTS",
              "ENABLE_TRACING_SOURCES"],
    "DATA TYPES": ["SCREENSHOT_TYPE"],
    "PATHS": ["SCREENSHOT_DIR", "VIDEO_DIR", "TRACE_DIR", "LOG_DIR"],
    "OCTANE": ["MODULE", "RELEASE", "SPRINT", "SUITE_ID", "OCTANE_URL", "SHAREDSPACE_ID", "WORKSPACE_ID",
               "WORKSPACE_USER", "AUTOMATED_TEST_ID", "LOG_DEFECT","CLIENT_ID","CLIENT_SECRET"],
    "MOBILE_NATIVE": ["automationName","platformName","platformVersion","deviceName","app","appPackage","appActivity"],
}
config_ini = ConfigLoader("default_config.ini",
                          os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "config.ini")),
                          config_required_structure)

