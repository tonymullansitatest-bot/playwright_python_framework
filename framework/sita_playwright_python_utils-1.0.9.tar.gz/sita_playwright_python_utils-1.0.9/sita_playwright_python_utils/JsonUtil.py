"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
from traceback import print_stack
import logging
import json
import os

from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework json_util", log_level=logging.INFO)


""" 
@purpose This utility handles Json 
@author Loredana Iuhas
"""


def convert_json_to_dictionary(json_string):
    """
        @purpose    Parse json string into a python dictionary
        @param      json_string
        """
    try:
        data_dict = json.loads(json_string)  # loads for str
        print('Data type of data_dict is ' + str(type(data_dict)))
        print(data_dict)
    except Exception as ex:
        logger.log('Could not convert json data into python dictionary')
        print_stack()
        raise ex
    return data_dict


def convert_py_dict_to_json_string(my_dict):
    """
        @purpose    Create a string with all key-value pairs of my_dict in json format
        @param      my_dict
        """
    try:
        my_json = json.dumps(my_dict)
    except Exception as ex:
        logger.log('Error creating a string with all key-value pairs of my_dict in json format')
        print_stack()
        raise ex
    return my_json


def pretty_print_json(data_json):
    """
        @purpose    sort json by keys, alphabetically, for human readability
        @param      data_json
        """
    try:
        my_json = json.dumps(data_json, indent=4, sort_keys=True)
    except Exception as ex:
        logger.log('Error sorting json data')
        print_stack()
        raise ex
    return my_json


def read_json_file(path: str):
    """
        @purpose    Read a json file from a specified path
        @param      path
        """
    try:
        with open(path, 'r') as file:
            return json.load(file)  # load for file object
    except Exception as ex:
        logger.log('Error while reading json file from specified path')
        print_stack()
        raise ex

def load_json_payload(file_path: str, dynamic_data: dict = None) -> dict:
    payload = read_json_file(file_path)

    if dynamic_data:
        logger.log(f"[JSON] Applying dynamic data: {json.dumps(dynamic_data, indent=2)}")

        payload_str = json.dumps(payload)

        for key, value in dynamic_data.items():
            payload_str = payload_str.replace(f"{{{{{key}}}}}", str(value))

        payload = json.loads(payload_str)
    logger.log(f"[JSON] Loaded Payload: {json.dumps(payload, indent=2)}")
    return payload

def write_to_json_file(file_name: str, info_dict: dict):
    """
        @purpose    write to a json file
        @param      file_name
        @param      info_dict
        """
    try:
        with open(file_name, 'w') as file:
            json.dump(info_dict, file)
    except Exception as ex:
        logger.log('Write to json file error')
        print_stack()
        raise ex


def delete_json_file(my_file_path):
    """
    @purpose   This functions deletes a json file
    @param my_file_path  location and name - full path
    """
    try:
        if os.path.exists(my_file_path):
            os.remove(my_file_path)
    except Exception as ex:
        logger.log('Read from json file error.')
        print_stack()
        raise ex


def get_all_files_from_directory(directory_path):
    """
    @purpose return all file names from a specified directory in a list
    @param directory_path:
    @return:
    """
    result = []
    try:
        for path in os.listdir(directory_path):
            if os.path.isfile(os.path.join(directory_path, path)):
                result.append(path)
        logger.log('The following files were found in folder: ')
        logger.log(result)
        return result
    except Exception as ex:
        logger.log('Getting all files from path has thrown an error.')
        print_stack()
        raise ex


def write_log_msg_to_json_file(file_name: str, log_msg: logger):
    """
        @purpose    write log messages to a json file
        @param      file_name
        @param      log_msg
        """
    try:
        with open(file_name, 'w') as file:
            json.dump(log_msg, file)
    except Exception as ex:
        logger.log('Write to json file error')
        print_stack()
        raise ex

def append_to_json_file(file_name, data_to_append):
    # Check if the file exists
    if os.path.exists(file_name):
        with open(file_name, 'r') as file:
            existing_data = json.load(file)
    else:
        existing_data = []

    existing_data.append(data_to_append)

    with open(file_name, 'w') as file:
        json.dump(existing_data, file, indent=4)