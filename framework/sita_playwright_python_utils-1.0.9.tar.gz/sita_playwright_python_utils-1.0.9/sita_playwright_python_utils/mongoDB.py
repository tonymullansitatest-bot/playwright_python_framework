from pymongo import MongoClient
import logging
from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="Framework MongoDB Utility ", log_level=logging.INFO)


def get_main_connection(client_server_string):
    """
    Establishes a connection to the MongoDB server.
    Args:
        client_server_string (str): The connection string for the MongoDB server.
    Returns:
        MongoClient: The MongoDB client object.
    Raises:
        Exception: If an error occurs while establishing the connection.
    """
    try:
        client = MongoClient(client_server_string)
        client.admin.command("ping")

        logger.log(f"Connected to database: {client}")

    except Exception as e:
        raise Exception("The following error occurred: ", e)
    return client


def close_main_connection(client):
    """
    Closes the connection to the MongoDB server.
    Args:
        client (MongoClient): The MongoDB client object.
    Raises:
        Exception: If an error occurs while closing the connection.
    """
    try:
        client.close()
        logger.log('Connection has been closed.')
    except Exception as e:
        raise Exception("The following error occurred: ", e)


def list_databases(client):
    """
    Lists all the databases in the MongoDB server.
    Args:
        client (MongoClient): The MongoDB client object.
    Returns:
        dict: A dictionary containing information about the databases.
    Raises:
        Exception: If an error occurs while listing the databases.
    """
    databases = client.admin.command("listDatabases")
    logger.log("Client databases: ")
    logger.log(databases)
    return databases


def get_database(client, database_name):
    """
    Gets a reference to the specified database.
    Args:
        client (MongoClient): The MongoDB client object.
        database_name (str): The name of the database.
    Returns:
        Database: The MongoDB database object.
    Raises:
        Exception: If an error occurs while getting the database.
    """
    try:
        database = client[database_name]
        print(f"Connected to database '{database_name}' successfully.")
        logger.log(f"Connected to database '{database_name}' successfully.")
    except Exception as e:
        raise Exception("The following error occurred: ", e)
    return database


def list_collections_names(database):
    """
    Lists all the collections in the specified database.
    Args:
        database (Database): The MongoDB database object.
    Returns:
        list: A list of collection names.
    Raises:
        Exception: If an error occurs while listing the collections.
    """
    collections = database.list_collection_names()
    logger.log("Database collections: ")
    logger.log(collections)

    return collections


def insert_document(collection, document):
    """
    Inserts a document into the specified collection.
    Args:
        collection (Collection): The MongoDB collection object.
        document (dict): The document to be inserted.
    Raises:
        Exception: If an error occurs while inserting the document.
    """
    try:
        result = collection.insert_one(document)
        logger.log(f"Document inserted successfully. Inserted ID: {result.inserted_id}")

    except Exception as e:
        raise Exception("The following error occurred: ", e)


def find_documents(collection, query):
    """
    Finds documents in the specified collection that match the given query.
    Args:
        collection (Collection): The MongoDB collection object.
        query (dict): The query to filter the documents.
    Returns:
        Cursor: A cursor object containing the matching documents.
    Raises:
        Exception: If an error occurs while finding the documents.
    """
    documents = collection.find(query)
    logger.log(f"Matching documents: ")

    for document in documents:
        logger.log(document)
    return documents


def update_document(collection, query, update):
    """
    Updates documents in the specified collection that match the given query.
    Args:
        collection (Collection): The MongoDB collection object.
        query (dict): The query to filter the documents.
        update (dict): The update to be applied to the documents.
    Raises:
        Exception: If an error occurs while updating the documents.
    """
    try:
        result = collection.update_many(query, update)

        logger.log(f"Documents updated successfully. Matched count: {result.matched_count}")
    except Exception as e:
        raise Exception("The following error occurred: ", e)


def delete_documents(collection, query):
    """
    Deletes documents from the specified collection that match the given query.
    Args:
        collection (Collection): The MongoDB collection object.
        query (dict): The query to filter the documents.
    Raises:
        Exception: If an error occurs while deleting the documents.
    """
    try:
        result = collection.delete_many(query)
        logger.log(f"Documents deleted successfully. Deleted count: {result.deleted_count}")
    except Exception as e:
        raise Exception("The following error occurred: ", e)


def get_collection(database, collection_name):
    """
    Gets a reference to the specified collection in the given database.
    Args:
        database (Database): The MongoDB database object.
        collection_name (str): The name of the collection.
    Returns:
        Collection: The MongoDB collection object.
    Raises:
        Exception: If an error occurs while getting the collection.
    """
    try:
        collection = database[collection_name]
        logger.log(f"Connected to collection '{collection_name}' successfully.")
    except Exception as e:
        raise Exception("The following error occurred: ", e)
    return collection


def get_document_schema(collection):
    """
        Retrieves the schema of documents in the specified collection.
        Args:
            collection (Collection): The MongoDB collection object.
        Returns:
            dict: A dictionary representing the schema of the documents.
        Raises:
            Exception: If an error occurs while retrieving the schema.
        """
    try:
        # Get a sample document from the collection
        sample_document = collection.find_one()

        # Extract the keys from the sample document
        keys = sample_document.keys()

        # Create a dictionary to store the schema
        schema = {}

        # Iterate over the keys and determine the data types
        for key in keys:
            value = sample_document[key]
            data_type = type(value).__name__
            schema[key] = data_type

        return schema
    except Exception as e:
        raise Exception("The following error occurred: ", e)


def get_document_by_id(collection, document_id):
    """
    Retrieves a document from the specified collection by its ID.
    Args:
        collection (Collection): The MongoDB collection object.
        document_id (str): The ID of the document to retrieve.
    Returns:
        dict: The document with the specified ID.
    Raises:
        Exception: If an error occurs while retrieving the document.
    """
    try:
        document = collection.find_one({"_id": document_id})
        return document
    except Exception as e:
        raise Exception("The following error occurred: ", e)


def get_document_by_field(collection, field, value):
    """
    Retrieves a document from the specified collection by a specific field.
    Args:
        collection (Collection): The MongoDB collection object.
        field (str): The field to search for.
        value (str): The value of the field to search for.
    Returns:
        dict: The document with the specified field value.
    Raises:
        Exception: If an error occurs while retrieving the document.
    """
    try:
        document = collection.find_one({field: value})
        return document
    except Exception as e:
        raise Exception("The following error occurred: ", e)
