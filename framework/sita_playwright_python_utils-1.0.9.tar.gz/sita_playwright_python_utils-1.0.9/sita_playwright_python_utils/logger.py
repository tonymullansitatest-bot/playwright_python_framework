"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import logging
import os
from datetime import datetime


class Logger:
    def __init__(self, log_dir, log_name="playwright_python_framework", log_level=logging.INFO):
        """
        Initializes the Logger instance.

        :param log_name: Name of the log file (without extension).
        :param log_level: Logging level (e.g., DEBUG, INFO, WARNING, ERROR, CRITICAL).
        :param log_dir: Directory where log files will be stored.
        """
        self.log_name = log_name
        self.log_level = log_level
        self.log_dir = log_dir
        self.logger = self._initialize_logger()

    def _initialize_logger(self):
        # Ensure the log directory exists
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        # Create a logger
        logger = logging.getLogger(self.log_name)
        logger.setLevel(self.log_level)

        # Avoid duplicate handlers if the logger is already configured
        if not logger.handlers:
            # Create a file handler
            log_file = os.path.join(self.log_dir, f"logs_{datetime.now().strftime('%m.%d.%Y_%H.%M.%S')}.log")
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(self.log_level)

            # Create a console handler
            console_handler = logging.StreamHandler()
            console_handler.setLevel(self.log_level)

            # Define the log format
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)

            # Add handlers to the logger
            logger.addHandler(file_handler)
            logger.addHandler(console_handler)

        return logger

    def log(self, message, log_level=None):
        """
        Logs a message at the specified or initialized log level.

        :param message: Message to log.
        :param log_level: Optional logging level for this specific message.
        """
        effective_level = log_level if log_level else self.log_level

        if effective_level == logging.DEBUG:
            self.logger.debug(message)
        elif effective_level == logging.INFO:
            self.logger.info(message)
        elif effective_level == logging.WARNING:
            self.logger.warning(message)
        elif effective_level == logging.ERROR:
            self.logger.error(message)
        elif effective_level == logging.CRITICAL:
            self.logger.critical(message)

    def set_level(self, log_level=None):
        """
        Updates the logging level dynamically or resets it to the initialized level.

        :param log_level: New logging level (if None, resets to the initialized level).
        """
        self.log_level = log_level if log_level else self.log_level
        self.logger.setLevel(self.log_level)
        for handler in self.logger.handlers:
            handler.setLevel(self.log_level)


class NullLogger:
    def __getattr__(self, name):
        # Return a callable (function) that does nothing
        return lambda *args, **kwargs: None
