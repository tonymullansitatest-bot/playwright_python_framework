"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""


from sqlite3 import Error
import sqlite3
import logging

from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger


logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="Framework SQL Utility", log_level=logging.INFO)


""" 
@purpose This utility handles sqlLite DB operations such as creating connection, executing query, fetching results and closing connection
@author Nidhi Garg
"""


def create_connection(db_file):
    """Create a database connection to a SQLite database."""
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        logger.log(f"Connected to database: {db_file}")
    except Error as e:
        print(e)
        logger.log('Error msg from create_connection : ' +str(e), log_level=logging.WARNING)

    return conn


def execute_query(conn, query):
    """Execute a single query."""
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
        logger.log("Query executed successfully")
    except Error as e:
        print(e)
        logger.log('Error msg from execute_query: ' + str(e),  log_level=logging.WARNING)


def fetch_all(conn, query):
    """Fetch all results from a query."""
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        return rows
    except Error as e:
        print(e)
        logger.log('Error msg from fetch_all: ' + str(e), log_level=logging.WARNING)
        return None


def fetch_one(conn, query):
    """Fetch a single result from a query."""
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        row = cursor.fetchone()
        return row
    except Error as e:
       logger.log('Error msg from fetch_one: ' + str(e), log_level=logging.WARNING)


def close_connection(conn):
    """Close the database connection."""
    if conn:
        conn.close()
        logger.log("Connection closed")
