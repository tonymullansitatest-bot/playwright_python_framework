"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import secrets
from playwright.async_api import expect
import string
import asyncio
from playwright.async_api import Page, Locator
from sita_playwright_python_utils.fixture_utils import logger

"""
    A utility class designed to provide reusable Playwright automation functions 
    that streamline interaction with web elements during UI testing.

    This class includes common operations like clicking elements, validating 
    visibility, interacting with dropdowns, and retrieving element attributes.
"""


class PlaywrightUtils:
    def __init__(self, page: Page):
        self.page = page

    async def navigate_to_url(self, url: str):
        """
        Navigate to a specified URL.

        Args:
            url (str): The destination URL.

        Raises:
            Exception: If navigation fails.
        """
        try:
            await self.page.goto(url)
            logger.log(f"Navigated to URL: {url}")
        except Exception as e:
            logger.log(f"Failed to navigate to URL {url}. Reason: {str(e)}")
            raise RuntimeError(f"Failed to navigate to URL {url}. Reason: {str(e)}")

    async def get_current_url(self) -> str:
        """
        Retrieve the current page URL.

        Returns:
            str: The active page URL.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            await asyncio.sleep(0)
            current_url = self.page.url
            logger.log(f"Current URL is: {current_url}")
            return current_url
        except Exception as e:
            logger.log(f"Failed to retrieve current URL. Reason: {str(e)}")
            raise RuntimeError(f"Failed to retrieve current URL. Reason: {str(e)}")

    async def wait_for_url(self, expected_url: str):
        """
        Wait until the page URL matches the expected value or pattern.

        Args:
            expected_url (str): The expected URL or pattern.

        Raises:
            Exception: If the URL does not match.
        """
        try:
            await self.page.wait_for_url(expected_url)
            logger.log(f"URL matched successfully: {expected_url}")
        except Exception as e:
            logger.log(f"URL did not match. Reason: {str(e)}")
            raise RuntimeError(f"URL did not match. Reason: {str(e)}")

    async def get_title(self) -> str:
        """
        Retrieve the title of the current page.

        Returns:
            str: The page title.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            title = await self.page.title()
            logger.log(f"Page title is: {title}")
            return title
        except Exception as e:
            logger.log(f"Failed to retrieve page title. Reason: {str(e)}")
            raise RuntimeError(f"Failed to retrieve page title. Reason: {str(e)}")

    async def refresh_page(self):
        """
        Reload the current page.

        Raises:
            Exception: If the refresh operation fails.
        """
        try:
            await self.page.reload()
            logger.log("Page reloaded successfully.")
        except Exception as e:
            logger.log(f"Failed to reload page. Reason: {str(e)}")
            raise RuntimeError(f"Failed to reload page. Reason: {str(e)}")

    async def click_element(self, element: Locator):
        """
        Click a visible element.

        Args:
            element (Locator): The Playwright locator representing the target element.

        Raises:
            Exception: If the element is not visible or the click action fails.
        """
        try:
            await element.click()
            logger.log(f"Clicked element successfully: {element}")
        except Exception as e:
            logger.log(f"Unable to click the element: Reason: {str(e)}")
            raise RuntimeError(f"Unexpected error occurred while clicking the element: {str(e)}")

    async def double_click_element(self, locator):
        """
        Perform a double-click action on an element.

        Args:
            locator (Locator): The element locator.

        Raises:
            Exception: If the action fails.
        """
        try:
            await locator.dblclick()
        except Exception as e:
            logger.log(f"Failed to double click element: {e}")
            raise RuntimeError(f"Unexpected error occurred while double-clicking the element: {str(e)}")

    async def type_values_in_a_textbox(self, locator: Locator, text: str):
        """
        Enter text into an input field.

        Args:
            locator (Locator): The input element locator.
            text (str): The text value to enter.

        Raises:
            Exception: If the text entry fails.
        """
        try:
            await locator.fill(text)
            logger.log(f"Text '{text}' entered successfully into input field.")
        except Exception as e:
            logger.log(f"Failed to fill text into 'input field': {str(e)}")
            raise RuntimeError(f"Failed to fill text into input field: {str(e)}")

    async def clear_element(self, locator):
        """
        Clear the value of an input field.

        Args:
            locator (Locator): The input element locator.

        Raises:
            Exception: If clearing the field fails.
        """
        try:
            await locator.fill("")  # Clear input
        except Exception as e:
            logger.log(f"Failed to clear element: {e}")
            raise RuntimeError(f"Failed to clear element: {str(e)}")

    async def press_key(self, key: str, locator: Locator = None):
        """
        Presses a specified key on a given element or the entire page.

        Args:
            key (str): The key to be pressed (e.g., 'Tab', 'ArrowDown', 'Enter', etc.)
            locator (Locator, optional): The element where the key should be pressed. If None, the key will be pressed globally on the page.
        """
        try:
            if locator:
                await locator.press(key)
                logger.log(f"Pressed key '{key}' on the element: {locator}")
            else:
                await self.page.keyboard.press(key)
                logger.log(f"Pressed key '{key}' on the page.")
        except Exception as e:
            logger.log(f"Failed to press key '{key}': {str(e)}")
            raise RuntimeError(f"Failed to press key '{key}': {str(e)}")

    async def assert_element_is_visible(self, element: Locator):
        """
        Determine whether an element is visible.

        Args:
            locator (Locator): The element locator.

        Returns:
            bool: True if the element is visible, otherwise False.

        Raises:
            Exception: If the visibility state cannot be determined.
        """
        try:
            await expect(element).to_be_visible()
        except Exception as e:
            logger.log(f"Element not visible: {str(e)}")
            raise RuntimeError(f"Element not visible: {str(e)}")

    async def is_element_enabled(self, locator: Locator) -> bool:
        """
        Determine whether an element is enabled.

        Args:
            locator (Locator): The element locator.

        Returns:
            bool: True if enabled, otherwise False.

        Raises:
            Exception: If the state cannot be determined.
        """
        try:
            enabled = await locator.is_enabled()
            logger.log(f"Element is {'enabled' if enabled else 'disabled'}.")
            return enabled
        except Exception as e:
            logger.log(f"Failed to check if element is enabled.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to check if element is enabled: {str(e)}")

    """
        # Method: is_element_disabled
        Checks whether the given element is disabled.

        This method waits for the element to be visible and returns True if the element
        is disabled (i.e., not interactable), otherwise returns False.
    """

    async def is_element_disabled(self, locator: Locator) -> bool:
        """
        Determine whether an element is disabled.

        Args:
            locator (Locator): The element locator.

        Returns:
            bool: True if disabled, otherwise False.

        Raises:
            Exception: If the state cannot be determined.
        """
        try:
            enabled = await locator.is_enabled()
            disabled = not enabled
            logger.log(f"Element is {'disabled' if disabled else 'enabled'}.")
            return disabled
        except Exception as e:
            logger.log(f"Failed to check if element is disabled.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to check if element is disabled: {str(e)}")

    async def wait_for_element_to_disappear(self, locator: Locator):
        """
        Wait until the specified element is no longer visible.

        Args:
            locator (Locator): The element locator.

        Raises:
            Exception: If the element remains visible.
        """
        try:
            await expect(locator).not_to_be_visible()
            logger.log("Element disappeared as expected.")
        except Exception as e:
            logger.log(f"Element did not disappear. Reason: {str(e)}")
            raise RuntimeError(f"Element did not disappear. Reason: {str(e)}")

    async def wait_for_page_load(self, state="networkidle"):
        """
        Wait for the page to reach a specific load state.

        Args:
            page: The Playwright page instance.
            state (str, optional): Load state (e.g., 'load', 'domcontentloaded', 'networkidle').

        Raises:
            Exception: If the page does not reach the desired state within the time.
        """
        try:
            await self.page.wait_for_load_state(state)
            logger.log(f"Page loaded successfully with state: {state}")
        except Exception as e:
            logger.log(f"Page did not load in time. Reason: {str(e)}")
            raise RuntimeError(f"Page did not load in time. Reason: {str(e)}")


    async def is_element_visible(self, element: Locator) -> bool:
        """
        Check whether an element is currently visible (without waiting).

        Args:
            element (Locator): The element locator.

        Returns:
            bool: True if visible, otherwise False.
        """
        try:
            return await element.is_visible()
        except Exception as e:
            logger.log(f"Failed to check element visibility.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to check element visibility: {str(e)}")

    async def is_element_exists(self, element: Locator) -> bool:
        """
        Check whether an element exists in the DOM (without waiting).

        Args:
            element (Locator): The element locator.

        Returns:
            bool: True if at least one matching element exists, otherwise False.
        """
        try:
            return await element.count() > 0
        except Exception as e:
            logger.log(f"Failed to check element existence.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to check element existence: {str(e)}")

    async def is_checked(self, locator: Locator) -> bool:
        """
        Determine whether a checkbox or radio button is selected.

        Args:
            locator (Locator): The checkbox or radio button locator.

        Returns:
            bool: True if selected, otherwise False.

        Raises:
            Exception: If the state cannot be retrieved.
        """

        try:
            checked = await locator.is_checked()
            logger.log(f"Checkbox/Radio button is {'checked' if checked else 'unchecked'}.")
            return checked
        except Exception as e:
            logger.log(f"Failed to check checkbox/radio button state. Reason: {str(e)}")
            raise RuntimeError(f"Failed to check checkbox/radio button state. Reason: {str(e)}")

    async def select_option_by_value_from_dropdown(self, locator: Locator, value: str):
        """
        Select an option from a dropdown using its value attribute.

        Args:
            locator (Locator): The dropdown locator.
            value (str): The value attribute of the option.

        Raises:
            Exception: If selection fails.
        """
        try:
            await locator.select_option(value)
        except Exception as e:
            logger.log(f"Failed to select dropdown option '{value}': {str(e)}")
            raise RuntimeError(f"Failed to select dropdown option '{value}': {str(e)}")

    async def select_option_by_label_from_dropdown(self, locator: Locator, label: str):
        """
        Select an option from a dropdown using its visible label.

        Args:
            locator (Locator): The dropdown locator.
            label (str): The visible label text.

        Raises:
            Exception: If selection fails.
        """
        try:
            await locator.select_option(label=label)
        except Exception as e:
            logger.log(f"Failed to select dropdown option by label '{label}': {str(e)}")
            raise RuntimeError(f"Failed to select dropdown option by label '{label}': {str(e)}")

    async def select_option_by_index_from_dropdown(self, locator: Locator, index: int):
        """
        Select an option from a dropdown using its index position.

        Args:
            locator (Locator): The dropdown locator.
            index (int): The index of the option.

        Raises:
            Exception: If selection fails.
        """
        try:
            await locator.select_option(index=index)
        except Exception as e:
            logger.log(f"Failed to select dropdown option by index '{index}': {str(e)}")
            raise RuntimeError(f"Failed to select dropdown option by index '{index}': {str(e)}")

    async def select_option_by_visible_text_from_dropdown(self, locator: Locator, visible_text: str):
        """
        Select an option from a dropdown using visible text.

        Args:
            locator (Locator): The dropdown locator.
            visible_text (str): The visible option text.

        Raises:
            Exception: If selection fails.
        """
        try:
            await locator.select_option(label=visible_text)
        except Exception as e:
            logger.log(f"Failed to select dropdown option by visible text '{visible_text}': {str(e)}")
            raise RuntimeError(f"Failed to select dropdown option by visible text '{visible_text}': {str(e)}")

    async def get_selected_option_from_dropdown(self, locator: Locator) -> str:
        """
        Retrieve the currently selected value from a dropdown.

        Args:
            locator (Locator): The dropdown locator.

        Returns:
            str: The selected value.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            actual_value = await locator.input_value()
            logger.log(f"Selected value in 'dropdown': '{actual_value}'")
            return actual_value
        except Exception as e:
            logger.log(f"Failed to verify selected value in 'dropdown': {str(e)}")
            raise RuntimeError(f"Failed to verify selected value in dropdown. Reason: {str(e)}")

    async def get_attribute_value(self, locator: Locator, attribute_name: str) -> str:
        """
        Retrieve the value of a specified attribute from an element.

        Args:
            locator (Locator): The target element.
            attribute_name (str): The attribute name (e.g., 'href', 'src').

        Returns:
            str: The attribute value.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            value = await locator.get_attribute(attribute_name)
            return value
        except Exception as e:
            logger.log(f"Failed to retrieve attribute '{attribute_name}' from 'element'.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to retrieve attribute '{attribute_name}' from 'element'.\nReason: {str(e)}")

    async def get_text(self, locator: Locator) -> str:
        """
        Retrieve the visible inner text of an element.

        Args:
            locator (Locator): The element locator.

        Returns:
            str: The trimmed inner text.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            text = await locator.inner_text()
            return (text or "").strip()
        except Exception as e:
            logger.log(f"Failed to retrieve inner text from 'element'.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to retrieve inner text from 'element'.\nReason: {str(e)}")

    async def navigate_back(self):
        """
        Navigate back to the previous page in the browser.

        Raises:
            Exception: If navigation fails.
        """
        try:
            await self.page.go_back()
            logger.log("Navigated back to the previous page.")
        except Exception as e:
            logger.log(f"Failed to navigate back. Reason: {str(e)}")
            raise RuntimeError(f"Failed to navigate back. Reason: {str(e)}")

    async def scroll_into_view(self, locator: Locator):
        """
        Scroll an element into the visible viewport if needed.

        Args:
            locator (Locator): The element locator.

        Raises:
            Exception: If scrolling fails.
        """
        try:
            await locator.scroll_into_view_if_needed()
            logger.log("Scrolled element into view.")
        except Exception as e:
            logger.log(f"Failed to scroll element into view.\nReason: {str(e)}")
            raise RuntimeError(f"Failed to scroll element into view.\nReason: {str(e)}")

    async def highlight_element(self, locator: Locator):
        """
        Highlight an element visually by applying a blue dotted border.

        Args:
            locator (Locator): The element locator.

        Raises:
            Exception: If highlighting fails.
        """
        try:
            await locator.evaluate("element => element.style.border = '3px dotted blue'")
        except Exception as e:
            logger.log("Highlight element failed.\nReason: " + str(e))
            raise RuntimeError("Highlight element failed.\nReason: " + str(e))


    def generate_random_string(self, length: int) -> str:
        """
        Generate a random alphabetic string of a specified length.

        Args:
            string_length (int): Desired length of the string.

        Returns:
            str: Randomly generated string.
        """
        alphabet = string.ascii_letters
        return ''.join(secrets.choice(alphabet) for _ in range(length))

    async def handle_alert(self, trigger_action, action: str = "accept", prompt_text: str = None) -> str:
        """
        Handles alert/confirm/prompt dialog triggered by an action.

        Args:
            trigger_action: coroutine that triggers alert
            action (str): "accept" or "dismiss"
            prompt_text (str): text for prompt dialog (optional)

        Returns:
            str: Alert message
        """
        try:
            async def dialog_handler():
                dialog = await self.page.wait_for_event("dialog")
                message = dialog.message
                logger.log(f"Dialog appeared with message: {message}")

                if dialog.type == "prompt" and prompt_text is not None:
                    await dialog.accept(prompt_text)
                    logger.log(f"Prompt accepted with text: {prompt_text}")
                elif action.lower() == "accept":
                    await dialog.accept()
                    logger.log("Dialog accepted.")
                else:
                    await dialog.dismiss()
                    logger.log("Dialog dismissed.")

                return message

            dialog_task = asyncio.create_task(dialog_handler())
            await trigger_action()
            return await dialog_task

        except Exception as e:
            logger.log(f"Failed to handle alert. Reason: {str(e)}")
            raise RuntimeError(f"Failed to handle alert. Reason: {str(e)}")

    async def get_elements_count(self, locator: Locator) -> int:
        """
        Retrieve the number of matched elements for a given locator.

        Args:
            locator (Locator): The element locator.

        Returns:
            int: Number of elements found.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            count = await locator.count()
            logger.log(f"Found {count} elements for locator: {locator}")
            return count
        except Exception as e:
            logger.log(f"Failed to get elements count: {str(e)}")
            raise RuntimeError(f"Failed to get elements count. Reason: {str(e)}")

    async def hover(self, locator: Locator):
        """
        Hover over an element.

        Args:
            locator (Locator): The element locator to hover over.

        Raises:
            Exception: If the hover action fails.
        """
        try:
            await locator.hover()
            logger.log("Hovered over the element successfully.")
        except Exception as e:
            logger.log(f"Failed to hover over element. Reason: {str(e)}")
            raise RuntimeError(f"Failed to hover over element. Reason: {str(e)}")

    async def get_all_dropdown_options(self, locator: Locator) -> list:
        """
        Retrieve all visible options from a dropdown.

        Args:
            locator (Locator): The dropdown locator.

        Returns:
            list: List of option texts.

        Raises:
            Exception: If retrieval fails.
        """
        try:
            options = await locator.locator('option').all_text_contents()
            logger.log(f"Dropdown options: {options}")
            return options
        except Exception as e:
            logger.log(f"Failed to get dropdown options: {str(e)}")
            raise RuntimeError(f"Failed to get dropdown options. Reason: {str(e)}")

    async def switch_window(self, window_index: int):
        """
        Switch to a browser window by index.

        Args:
            window_index (int): Index of the target window.

        Raises:
            Exception: If index is invalid or switching fails.
        """
        try:
            await asyncio.sleep(0)
            all_pages = self.page.context.pages
            if window_index < len(all_pages):
                self.page = all_pages[window_index]
                logger.log(f"Switched to window {window_index}.")
            else:
                raise IndexError("Invalid window index.")
        except IndexError as e:
            logger.log(f"Failed to switch window: {str(e)}")
            raise
        except Exception as e:
            logger.log(f"Failed to switch window: {str(e)}")
            raise RuntimeError(f"Failed to switch window. Reason: {str(e)}")

    async def open_new_tab(self):
        """
        Open a new browser tab and switch context to it.

        Raises:
            Exception: If tab creation fails.
        """
        try:
            new_page = await self.page.context.new_page()
            self.page = new_page
            logger.log("Opened a new tab.")
        except Exception as e:
            logger.log(f"Failed to open a new tab. Reason: {str(e)}")
            raise RuntimeError(f"Failed to open a new tab. Reason: {str(e)}")

    async def close_tab(self):
        """
        Close the current browser tab.

        Raises:
            Exception: If closing fails.
        """
        try:
            await self.page.close()
            logger.log("Closed the current tab.")
        except Exception as e:
            logger.log(f"Failed to close tab. Reason: {str(e)}")
            raise RuntimeError(f"Failed to close tab. Reason: {str(e)}")