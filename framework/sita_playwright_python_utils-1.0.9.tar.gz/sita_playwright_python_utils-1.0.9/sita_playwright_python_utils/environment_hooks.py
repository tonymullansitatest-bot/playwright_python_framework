"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
from behave import use_fixture
import logging

from playwright.async_api import async_playwright

from sita_playwright_python_utils import OctaneUtility
from sita_playwright_python_utils.fixture_utils import (set_environment, start_tracing, stop_tracing,
                                                        attach_screenshot_if_failed, rename_video_file)
from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.fixtures import browser, browser_context, page, api_request
from sita_playwright_python_utils.logger import Logger
from src.pages.pages import Pages

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework environment_hooks", log_level=logging.INFO)

from sita_playwright_python_utils.OctaneUtility import (
    JsonUtil,
    logger,
)


async def before_all_hook(context):
    """
    Setup to run before all tests.
    Args:
        context: Behave context object for sharing data.
    """
    mode = context.config.userdata.get('execution_mode', '').lower()
    context.execution_mode = mode
    logger.log(f"Execution mode set to: {mode}")

    context.base_url = set_environment(context)
    logger.log(f"Base URL: {context.base_url}")
    JsonUtil.delete_json_file("./debug/octaneData.json")
    context.playwright = await async_playwright().start()


async def after_all_hook(context):
    """
    Teardown to run after all tests.

    Args:
        context: Behave context object for shared data.
    """
    if hasattr(context, "browser") and context.browser:
        await context.browser.close()

    if hasattr(context, "playwright"):
        await context.playwright.stop()

    if 'octane' not in context.config.userdata:
        raise ValueError("No octane switch specified. Please provide an octane = \"\" in the behave.ini file.")
    logger.log(f"Octane is set to: {context.config.userdata['octane']}")
    if context.config.userdata['octane'] in ('True', 'true'):
        OctaneUtility.send_local_suite_run_results_to_octane()


async def before_scenario_hook(context, scenario):
    """
    Setup to run before each scenario. Initializes the page and page objects.
    """
    mode = context.execution_mode

    if mode == "api":
        logger.log("Running API scenario in API mode")
        await use_fixture(api_request, context)

    elif mode == "hybrid":
        logger.log("Running Hybrid scenario (UI + API) mode")
        await use_fixture(api_request, context)
        await use_fixture(browser, context)
        await use_fixture(browser_context, context)

        if config_ini.get_boolean('DEBUG', 'ENABLE_TRACING'):
            await start_tracing(context)

        await use_fixture(page, context)
        context.pages = Pages(context)

    else:
        # Default to UI mode if no valid mode is specified
        logger.log("Running UI scenario in UI mode (default)")
        await use_fixture(browser, context)
        await use_fixture(browser_context, context)

        if config_ini.get_boolean('DEBUG', 'ENABLE_TRACING'):
            await start_tracing(context)

        await use_fixture(page, context)
        context.pages = Pages(context)


async def after_scenario_hook(context, scenario):
    """
    Teardown to run after each scenario.
    Handles cleanup safely for UI, API, and Mixed modes.
    Stop Tracing
    screenshot attach
    ️Close page (UI & Hybrid)
    Close browser context (UI & Hybrid)
    Rename video if recording enabled (UI only)
    Octane reporting (if enabled)
    """

    if hasattr(context, "api_request"):
        await context.api_request.dispose()

    if config_ini.get_boolean('DEBUG', 'ENABLE_TRACING'):
        await stop_tracing(context, scenario)

    if scenario.status == "failed" and hasattr(context, "page"):
        await attach_screenshot_if_failed(context, scenario)

    if hasattr(context, "page"):
        await context.page.close()

    if hasattr(context, "browser_context"):
        await context.browser_context.close()

    if (
        config_ini.get_boolean('DEBUG', 'ENABLE_RECORDING')
        and hasattr(context, "browser_context")
    ):
        await rename_video_file(context, scenario)

    if context.config.userdata['octane'] in ('True', 'true'):
        OctaneUtility.build_local_suite_run_results(context)


