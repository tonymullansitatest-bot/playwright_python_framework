"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import logging
import ssl
import traceback
import subprocess
import os
import requests

from sita_playwright_python_utils import ApiUtil, JsonUtil
from operator import itemgetter
import json
import time
from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger, NullLogger

"""
This class is a helper class and contains the required methods for Octane Integration
"""
if config_ini.get("OCTANE", "DEBUG") == "True":
    logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework octane_utils", log_level=logging.INFO)
else:
    logger = NullLogger()

# """   Octane switch   """
# with_octane =  behave_ini.get('behave.userdata', 'octane')
"""   Log defect switch   """
log_defect = config_ini.get('OCTANE', 'LOG_DEFECT')
"""   Octane application module id   """
module = config_ini.get('OCTANE', 'MODULE')
"""   Octane release id   """
release = config_ini.get('OCTANE', 'RELEASE')
"""   Octane sprint id   """
sprint = config_ini.get('OCTANE', 'SPRINT')
"""   Octane url   """
octane_url = config_ini.get('OCTANE', 'OCTANE_URL')
"""   Octane shared space id   """
shared_space_id = config_ini.get('OCTANE', 'SHAREDSPACE_ID')
"""   Octane Workspace id   """
workspace_id = config_ini.get('OCTANE', 'WORKSPACE_ID')
"""   Octane workspace user id   """
workspace_user = config_ini.get('OCTANE', 'WORKSPACE_USER')

OctaneProd_parentID = "34001"
OctaneProd_servityID = "list_node.severity.high"
OctaneProd_defectTypeID = "xg0n5qyn976qdce726zdowk86"
OctaneProd_env_details_long_udf = "CI/CD Automation"
#"""   Octane username   """
#user_id = config_ini.get('OCTANE', 'USER_ID')
#"""   Octane password   """
#password = config_ini.get('OCTANE', 'PASSWORD')
"""   Octane suite id   """
suite_id = config_ini.get('OCTANE', 'SUITE_ID')
"""   Octane automated test id   """
automated_test_id = config_ini.get('OCTANE', 'AUTOMATED_TEST_ID')

"""   Octane client id """
client_id = config_ini.get('OCTANE', 'CLIENT_ID')
"""   Octane secret id """
client_secret = config_ini.get('OCTANE', 'CLIENT_SECRET')
"""   Octane API endpoints   """

"""   Octane API endpoints   """
header = {'Content-Type': 'application/json'}
api_shared_spaces = "/api/shared_spaces/"
api_workspaces = "/workspaces/"
api_tests = "/tests/"
octane_defects = "/defects/"

shared_space = "/api/shared_spaces/"
workspace = "/workspaces/"
application_json = 'application/json'
error_in_get_all_testcases = "Error in Octane Integration get all testcases runs under suite run"
AUTHENTICATION_FAILED_MSG = "Authentication failed. Cannot proceed."

OCTANE_DATA_FILE_PATH = "./debug/octaneData.json"
def get_time_stamp():
    """
    @purpose   Generate current time stump
    """
    return str(round(time.time() * 1000))


def custom_string_builder(*args: str) -> str:
    """
    @purpose This is an url builder function that appends the string values passed as parameters
    """
    return "".join(args)

# I would take it directly from the config file
# def get_octane_switch_status():
#     """
#     @purpose Return true or false based on withOctane value from Octane properties file
#     """
#     return with_octane.lower() == 'true'


def is_numeric_string(s):
    """Check if the string is a representation of a numeric value."""
    if not isinstance(s, str):  # Check if the item is a string
        return False
    """" Check if the string represents a float or an integer """
    try:
        float(s)  # This will handle both int and float representation
        return True
    except ValueError:
        return False


def payload_for_link_test_case_to_a_suite(test_case_id_list):
    """
    Link testcase to suite payload
    """
    root = {}
    data = [{} for _ in range(len(test_case_id_list))]
    for i in range(len(test_case_id_list)):
        author = {'type': 'workspace_user', 'id': workspace_user}
        data[i]['author'] = author
        test = {'type': 'test', 'id': test_case_id_list[i]}
        data[i]['test'] = test
        test_suite = {'type': 'test_suite', 'id': suite_id}
        data[i]['test_suite'] = test_suite
    root['data'] = data
    logger.log('root["data"]')
    logger.log(root['data'])
    return json.dumps(root)

def link_manual_test_case_with_suite(all_test_cases_in_suite):
    """
    Link one or more test cases with a test suite
    """
    logger.log("Linking test cases to suite")

    url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/test_suite_link_to_tests"
    logger.log(url)

    payload = payload_for_link_test_case_to_a_suite(all_test_cases_in_suite)
    logger.log('----payload ')
    logger.log(payload)

    # Authenticate and get token
    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log("Authentication failed", log_level=logging.WARNING)
        return None

    headers = get_authenticated_header(lwsso_token)

    # Prepare args
    args = {'url': url,'headers': headers,'data': payload}

    # Send request
    data = ApiUtil.post_request_with_data(**args)
    logger.log("link one test case with a test suite api response " + str(data))
    return data

#SUITE RUNS NAME IS HARDCODED?
def create_suite_run():
    """
    @purpose    Create a suite run
    """
    payload = "{'data':[{'name':'" + config_ini.get('OCTANE', 'SUITE_RUN_NAME') + "','test':{'type':'test_suite','id':'" \
              + suite_id + "','name':'MANUAL RUN TEST SUITE'},'author':{'type':'workspace_user','id':'" \
              + workspace_user + "'},'native_status':{'type':'list_node','id':" \
                                 "'list_node.run_native_status.not_completed'},'release':{'type':'release','id':" \
                                 "'" + release + "'}}]}"
    url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/suite_run"

    # Get the session token and header
    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
        return []

    header = get_authenticated_header(lwsso_token)


    args = {'url': url, 'headers': header, 'data': payload.replace("'", "\"")}
    data = ApiUtil.post_request_with_data(**args)
    logger.log("create a suite run api response " + str(data))
    return data['data'][0]['id']

def get_a_single_suite_run_tests(last_run_id: str):
    """
    @purpose Gets a single run_suite details including test ids
    """
    url = custom_string_builder(octane_url, api_shared_spaces, shared_space_id, api_workspaces,
                                workspace_id, '/suite_run/', last_run_id, '?fields=runs_in_suite')
    logger.log(url)

    # Get the session token and header
    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
        return []

    header = get_authenticated_header(lwsso_token)


    response = ApiUtil.get_request_with_kwargs(url=url, headers=header, params='')
    logger.log(response)
    ids_list = response['runs_in_suite']['data']
    res = list(map(itemgetter('id'), ids_list))
    logger.log(res)
    return res

def get_all_test_runs_under_suite_run(suite_run_id):
    """
    @purpose     Get all newly created manual runs from a suite run
    """
    params = {'HPECLIENTTYPE': 'HPE_REST_API_TECH_PREVIEW', 'fields': 'runs_in_suite'}
    url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/runs/" + suite_run_id

    # Get the session token and header
    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
        return {}

    header_value = get_authenticated_header(lwsso_token)

    args = {'url': url, 'headers': header_value,  'params': params}

    data = ApiUtil.get_request_with_kwargs(**args)
    logger.log("Get all newly created manual runs from a suite run api response " + str(data))

    dictionary_of_data = data['runs_in_suite']['data']
    test_details_name_with_id = {}
    all_test_cases_in_suite = []
    for keys in dictionary_of_data:
        all_test_cases_in_suite.append(keys['id'])
    for val in all_test_cases_in_suite:
        params = {'HPECLIENTTYPE': 'HPE_REST_API_TECH_PREVIEW', 'fields': 'test', 'ALM-OCTANE-TECH-PREVIEW': 'true'}
        url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/manual_runs/" + val
        args = {'url': url, 'headers': header_value, 'params': params}

        data = ApiUtil.get_request_with_kwargs(**args)
        logger.log("Get testcase name against testcase ID  api response " + str(data))

        name = data['test']['name']
        test_details_name_with_id[name] = val
    return test_details_name_with_id


"""  Function to read JSON file and convert to Python list """


def read_json_file(file_path):
    with open(file_path, 'r') as file:
        python_list = json.load(file)  # read and convert JSON to Python list
    return python_list


"""" Match local scenario results with list of scenario runs retrieved from Octane """


def match_scenarios(scenario_dict, scenario_list):
    matches = {}
    logger.log('In matches_scenarios')
    """ Iterate through both dictionary and list """
    for key, value in scenario_dict.items():
        """ Iterate through the list of dictionaries """
        logger.log('- dictionary key, value:')
        logger.log(key)
        logger.log(value)
        for scenario in scenario_list:
            logger.log(scenario)
            """ Check if the key matches with the scenario name and if the IDs match """
            """ Extract the status from the scenario """
            if key in scenario:
                matches[key] = {
                    'ID': value,
                    'Status': scenario['status'],
                    'StackTrace': scenario.get('stack_trace')
                }
                logger.log(key)
                logger.log(value)
    return matches

##Method with session
def update_test_run_status(all_manual_run_status):
    """
    @purpose    Update manual runs status
    """
    payload_value = {}
    data = []
    for run_id in all_manual_run_status.keys():
        status = all_manual_run_status[run_id]
        if status == 'PASS' or status == 'FAIL':
            status = status + 'ED'
        else:
            status = "skipped"
        status = status.lower()
        root = {}
        phase = {'type': 'list_node', 'id': 'list_node.run_native_status.' + status}
        root['native_status'] = phase
        sprints = {'type': 'sprint', 'id': sprint}
        root['sprint'] = sprints
        releases = {'type': 'release', 'id': release}
        root['release'] = releases
        root['id'] = run_id
        data.append(root)
    payload_value['data'] = data
    payload = json.dumps(payload_value)
    url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/manual_runs"
    param = {'HPECLIENTTYPE': 'HPE_REST_API_TECH_PREVIEW'}

    # Get the session token and header
    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
        return {}

    header_value = get_authenticated_header(lwsso_token)



    args = {'url': url, 'headers': header_value, 'data': payload,
            'params': param}
    data = ApiUtil.put_request_with_data_and_params(**args)
    logger.log("update one manual run status api response" + str(data))
    return data


"""     New Implementation for Gherkin tests    """

def get_authenticated_header(lwsso_token):
    return {
        'Content-Type': application_json,
        'Accept': application_json,
        'Cookie': f'LWSSO_COOKIE_KEY={lwsso_token}'
    }

def authenticate_and_get_session(client_id, client_secret):
    """
        Authenticate and get the LWSSO token (LWSSO_COOKIE_KEY)
        """
    url = octane_url + "//authentication/sign_in/"
    request_body = {
        'client_id': client_id,
        'client_secret': client_secret
    }

    try:
        response = requests.post(url, json=request_body, verify=ssl.CERT_NONE)
        response.raise_for_status()

        for cookie_name, cookie_value in response.cookies.items():
            if cookie_name == "LWSSO_COOKIE_KEY":
                return cookie_value

        logger.log("LWSSO_COOKIE_KEY not found in response.", log_level=logging.WARNING)
    except requests.exceptions.RequestException as e:
        logger.log(f"Authentication failed: {e}", log_level=logging.WARNING)
        raise

def get_all_test_cases_linked_to_a_suite2():
    """
        Get all test cases linked to a test suite in Octane.
        """
    logger.log('In get_all_test_cases_linked_to_a_suite2')

    url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/test_suite_link_to_tests"
    logger.log(url)

    params = {'query': '"(test_suite={id=' + suite_id + '};!test={null})"' +
                       suite_id + '^}"', 'fields': ' test{id,name,name } '}
    logger.log(params)

    # Get the token and header
    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
        return []

    header = get_authenticated_header(lwsso_token)

    args = {'url': url, 'headers': header, 'params': params}
    data = ApiUtil.get_request_with_kwargs(**args)
    logger.log("Get all linked test case with a test suite 2  data: " + str(data))
    """ Create a list to hold the extracted test entities and their internal IDs """
    test_entities = []

    """ Check if 'data' is present in the input dictionary """
    if 'data' in data:
        for item in data['data']:
            """ Retrieve the test information """
            test_info = item.get('test')
            if test_info:
                """ Get the test ID """
                test_id = test_info.get('id')
                """ Get the test name """
                test_name = test_info.get('name')
                test_entities.append({'id': test_id, 'name': test_name})
    logger.log('test_entities')
    logger.log(test_entities)
    """ Create a list to hold the extracted IDs """
    test_ids = []
    """ Iterate through the list of test entities """
    for entity in test_entities:
        test_ids.append(entity['id'])
    logger.log('test_ids:')
    logger.log(test_ids)
    return test_ids

""" Clean scenario name for scenarios with outline """
def remove_after_delimiter(text: str, delimiter: str = '--') -> str:
    # Split the string at the delimiter and return the first part
    return text.split(delimiter)[0].strip()


def build_local_suite_run_results(context):
    tags = context.scenario.tags
    scenario_id = [item for item in tags if is_numeric_string(item)]

    scenario_name = context.scenario.name
    if ' -- @' in scenario_name:
        scenario_name = remove_after_delimiter(scenario_name)

    stack_trace = None

    if context.scenario.status == "failed":
        if context.scenario.exception:
            stack_trace = "".join(
                traceback.format_exception(
                    type(context.scenario.exception),
                    context.scenario.exception,
                    context.scenario.exception.__traceback__
                )
            )

    scenario_test_data = {
        scenario_name: scenario_id,
        'status': str(context.scenario.status),
        'stack_trace': stack_trace
    }

    JsonUtil.append_to_json_file(
        file_name=OCTANE_DATA_FILE_PATH,
        data_to_append=scenario_test_data
    )

def check_pass_status(input_string):
    """ Check if the string contains 'pass' (case insensitive) """
    if 'pass' in input_string.lower():
        return 'PASS'
    else:
        return 'FAIL'


def extract_local_ids(file_data):
    local_ids = []
    for entry in file_data:
        for key, values in entry.items():
            if key in ("status", "stack_trace"):
                continue
            if isinstance(values, list):
                local_ids.extend(int(v) for v in values if str(v).isdigit())
    return local_ids

NO_STACK_TRACE_MSG = "No stack trace available"

def process_test_run(match_item, suite_run_id):
    run_id = match_item["ID"]
    status = check_pass_status(match_item["Status"])

    createteststep(run_id)
    update_test_run_status({run_id: status})

    if status != "FAIL":
        return

    stack_trace = match_item.get("StackTrace") or NO_STACK_TRACE_MSG
    defect_id = createDefect(run_id, stack_trace)

    if defect_id:
        link_defect_to_run(defect_id, suite_run_id)
        upload_run_attachment(suite_run_id)

    else:
        logger.log(
            "Defect creation failed, cannot link defect to run.",
            log_level=logging.WARNING
        )

def send_local_suite_run_results_to_octane():
    file_data = JsonUtil.read_json_file(OCTANE_DATA_FILE_PATH)
    logger.log("File type: " + str(type(file_data)))
    logger.log(file_data)

    result = get_all_test_cases_linked_to_a_suite2()
    converted_result = [int(item) for item in result]

    local_ids = extract_local_ids(file_data)
    logger.log("Local ids:")
    logger.log(local_ids)

    missing_ids = list(set(local_ids) - set(converted_result))
    if missing_ids:
        link_manual_test_case_with_suite([str(i) for i in missing_ids])

    suite_run_id = create_suite_run()

    tests_in_suite_run = get_all_test_runs_under_suite_run(suite_run_id)
    json_list = read_json_file(OCTANE_DATA_FILE_PATH)

    match = match_scenarios(
        scenario_dict=tests_in_suite_run,
        scenario_list=json_list
    )

    for match_item in match.values():
        process_test_run(match_item, suite_run_id)

    JsonUtil.delete_json_file(OCTANE_DATA_FILE_PATH)


def createteststep(test_run_id):
    params = {'fields': 'id,description'}
    url = octane_url + shared_space + shared_space_id + workspace + workspace_id + "/runs/" + test_run_id +"/steps"
    logger.log(url)

    lwsso_token = authenticate_and_get_session(client_id, client_secret)
    if not lwsso_token:
        logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
        return {}
    header_value = get_authenticated_header(lwsso_token)

    # header_value['Content-Type'] = 'application/json'
    args = {'url': url, 'headers': header_value, 'params': params}
    logger.log(args)
    data = ApiUtil.put_request_with_params(**args)
    logger.log("Get all newly created steps " + str(data))






def createDefect(run_id, stack_trace):
    """
    @purpose Create a defect linked to a test run
    """
    try:
        description_text = (
            "Automation Test Failure\n\n"
            f"Test Run ID: {run_id}\n\n"
            "Stack Trace:\n"
            f"{stack_trace}"
        )
        payload = {
            "data": [{
                "parent": {"type": "work_item", "id": OctaneProd_parentID},
                "author": {"type": "workspace_user", "id": workspace_user},
                "product_areas": {
                    "data": [{"type": "product_area", "id": module}]
                },
                "subtype": "defect",
                "phase": {"type": "phase", "id": "phase.defect.new"},
                "name": f"Automation failure - Run {run_id}",
                "description": description_text,
                "detected_by": {"type": "workspace_user", "id": workspace_user},
                "release": {"type": "release", "id": release},
                "severity": {
                    "type": "list_node",
                    "id": OctaneProd_servityID
                },
                "defect_type": {  #
                    "type": "list_node",
                    "id": OctaneProd_defectTypeID
                },
                "env_details_long_udf": OctaneProd_env_details_long_udf
            }]
        }

        url = (
            octane_url + shared_space + shared_space_id +
            workspace + workspace_id +
            "/work_items?fetch_single_entity=true"
        )

        lwsso_token = authenticate_and_get_session(client_id, client_secret)
        if not lwsso_token:
            logger.log("Authentication failed", log_level=logging.WARNING)
            return None

        headers = get_authenticated_header(lwsso_token)
        # headers["Content-Type"] = "application/json"

        response = ApiUtil.post_request_with_data(
            url=url,
            headers=headers,
            data=json.dumps(payload)
        )

        defect_id = (
            response.get("data", [{}])[0].get("id")
            if isinstance(response, dict)
            else None
        )

        return defect_id

    except Exception as e:
        logger.log(
            "Exception while creating defect: " + str(e),
            log_level=logging.ERROR
        )
        return None


def link_defect_to_run(defect_id, run_id):
    """
    @purpose    Link an existing defect (work_item) to a test run
    """
    try:
        payload_value = {
            "id": defect_id,
            "run": {
                "data": [
                    {
                        "type": "run",
                        "id": run_id
                    }
                ]
            }
        }

        payload = json.dumps(payload_value)
        url = f"{octane_url}{shared_space}{shared_space_id}{workspace}{workspace_id}/work_items/{defect_id}"
        param = {'HPECLIENTTYPE': 'HPE_REST_API_TECH_PREVIEW'}

        logger.log("Linking defect to run...")
        logger.log("URL:", url)
        logger.log("Payload:", payload)

        # Authenticate
        lwsso_token = authenticate_and_get_session(client_id, client_secret)
        if not lwsso_token:
            logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)

            return False

        header_value = get_authenticated_header(lwsso_token)
        # header_value['Content-Type'] = 'application/json'

        args = {
            'url': url,
            'headers': header_value,
            'data': payload,
            'params': param
        }

        response = ApiUtil.put_request_with_data_and_params(**args)

        logger.log("Link defect to run response:", response)
        logger.log("Link defect to run API response: " + str(response))
        return True

    except Exception as e:
        logger.log(" Exception while linking defect to run: " + str(e), log_level=logging.ERROR)

        logger.log(str(e))
        return False

def upload_run_attachment(run_id):
    """
    @purpose Generate Allure report and upload it to Octane run
    """

    try:

        logger.log("Generating Allure report...")

        subprocess.run(
            "allure generate allure-results --clean -o single-html --single-file",
            shell=True,
            check=True
        )

        report_path = os.path.join(os.getcwd(), "single-html", "index.html")

        logger.log("Report path: " + report_path)

        if not os.path.exists(report_path):
            logger.log("Allure report not found!", log_level=logging.ERROR)
            return False

        entity_payload = {
            "name": "index.html",
            "owner_run": {
                "type": "run",
                "id": run_id
            }
        }

        url = f"{octane_url}{shared_space}{shared_space_id}{workspace}{workspace_id}/attachments"

        param = {
            'HPECLIENTTYPE': 'HPE_REST_API_TECH_PREVIEW'
        }

        logger.log("Uploading report to Octane Run: " + str(run_id))

        # Authenticate
        lwsso_token = authenticate_and_get_session(client_id, client_secret)

        if not lwsso_token:
            logger.log(AUTHENTICATION_FAILED_MSG, log_level=logging.WARNING)
            return False

        header_value = get_authenticated_header(lwsso_token)

        # Remove content-type because multipart will be set automatically
        header_value.pop("Content-Type", None)

        with open(report_path, "rb") as file:

            files = {
                "entity": (None, json.dumps(entity_payload), "application/json"),
                "content": ("index.html", file, "text/html")
            }

            args = {
                'url': url,
                'headers': header_value,
                'files': files,
                'params': param
            }

            response = ApiUtil.post_request_with_files(**args)

            logger.log("Upload attachment status: " + str(response.status_code))
            logger.log("Upload attachment response: " + response.text)

            if response.status_code == 201:
                logger.log("Attachment uploaded successfully to Octane.")
                return True
            else:
                logger.log("Attachment upload failed.", log_level=logging.ERROR)
                return False

    except Exception as e:
        logger.log(
            "Exception while uploading attachment: " + str(e),
            log_level=logging.ERROR
        )
        return False