"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import logging, os

from behave import fixture
from playwright.async_api import async_playwright

from sita_playwright_python_utils.fixture_utils import choose_browser, choose_channel, set_desktop_screen_size
from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework hooks", log_level=logging.INFO)


@fixture
async def browser(context):
    """
    Fixture to initialize the Playwright browser instance.

    Args:
        context: Behave context object for sharing data.
    """
    if 'browser' not in context.config.userdata:
        raise ValueError("No browser specified. Please provide a browser = \"\" in the behave.ini file.")

    browser_name = context.config.userdata['browser']
    headless = config_ini.get_boolean('BROWSER', 'HEADLESS')
    channel = choose_channel(context)

    logger.log(f"Browser: {browser_name}")
    logger.log(f"Headless: {headless}")

    context.browser = await getattr(context.playwright, choose_browser(context)).launch(
        headless=headless,
        channel=channel
    )

    logger.log(f"Initialized browser: {context.browser}")


@fixture
async def browser_context(context):
    """
    Fixture to initialize the Playwright browser context.

    Args:
        context: Behave context object for sharing data.
    """
    if 'browser_platform' not in context.config.userdata:
        raise ValueError(
            "No browser platform specified. Please provide a browser_platform = \"\" in the behave.ini file.")

    browser_platform = context.config.userdata['browser_platform']
    logger.log(f"Browser was opened on: {browser_platform}")

    logger.log(f"Ignore HTTPS errors: {config_ini.get_boolean('BROWSER', 'IGNORE_HTTP_ERRORS')}")
    logger.log(f"Enable video recording: {config_ini.get_boolean('BROWSER', 'ENABLE_RECORDING')}")

    state_file=None
    if config_ini.get_boolean('MFA','MFA_ENABLED'):
        try:
         state_file = config_ini.get('MFA', 'MFA_STORAGE_STATE')
         print(f"MFA_STORAGE_STATE: {state_file}")
        except TypeError as e:
            state_file = None
        logger.log(f"No MFA storage state provided: {e}", log_level=logging.WARNING)

    if browser_platform == "desktop":
        screen_width, screen_height = set_desktop_screen_size()
        logger.log(f"Desktop screen width: {screen_width}, screen height: {screen_height}")

        context.browser_context = await context.browser.new_context(
            storage_state=state_file,
            ignore_https_errors=config_ini.get_boolean('BROWSER', 'IGNORE_HTTP_ERRORS'),
            record_video_dir=config_ini.get('PATHS', 'VIDEO_DIR') if config_ini.get_boolean('DEBUG',
                                                                                            'ENABLE_RECORDING') else None,
            viewport={"width": screen_width, "height": screen_height},
        )
    elif browser_platform == "mobile":

        mobile_device_model = config_ini.get('MOBILE', 'MOBILE_DEVICE_MODEL')
        if not mobile_device_model:
            logger.log("No mobile device model specified in config.ini", log_level=logging.ERROR)
            raise ValueError("MOBILE_DEVICE_MODEL is not set in config.ini")
        mobile_device = context.playwright.devices[mobile_device_model]


        if choose_browser(context) == "firefox":
            mobile_device.pop("is_mobile")

        logger.log(f"Mobile device capabilities: {mobile_device}")

        context.browser_context = await context.browser.new_context(
           storage_state=state_file,
           **mobile_device,
           record_video_dir=config_ini.get('PATHS', 'VIDEO_DIR') if config_ini.get_boolean('DEBUG',
                                                                                            'ENABLE_RECORDING') else None,
           ignore_https_errors=config_ini.get_boolean('BROWSER', 'IGNORE_HTTP_ERRORS'),
        )
    else:
        logger.log(f"Invalid browser platform: {browser_platform}. Use 'desktop' or 'mobile'", log_level=logging.ERROR)
        raise ValueError(f"Invalid browser platform: {browser_platform}. Use 'desktop' or 'mobile'")


@fixture
async def page(context):
    """
    Fixture to initialize a new browser page.

    Args:
        context: Behave context object for sharing data.
    """
    context.page = await context.browser_context.new_page()

    # Get the user agent from the page
    user_agent = await context.page.evaluate('navigator.userAgent')
    logger.log(f"User Agent: {user_agent}")


@fixture
async def api_request(context):
    """
    Used only for API scenarios
    """

    if 'environment' not in context.config.userdata:
        raise ValueError("Environment not specified in behave.ini")

    env_key = context.config.userdata['environment']

    if env_key not in context.config.userdata:
        raise ValueError(f"Environment URL for '{env_key}' not defined in behave.ini")

    base_url = context.config.userdata["api_"+env_key]

    context.api_request = await context.playwright.request.new_context(
        base_url=base_url,
        ignore_https_errors=config_ini.get_boolean('BROWSER', 'IGNORE_HTTP_ERRORS')
    )

    logger.log(f"APIRequestContext initialized with base URL: {base_url}")