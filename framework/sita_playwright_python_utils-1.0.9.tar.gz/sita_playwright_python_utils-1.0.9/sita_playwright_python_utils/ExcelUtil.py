"""Copyright © SITA Information Networking Computing UK Ltd 2022-2026 Confidential.All rights reserved."""
import logging
import os
from pathlib import Path

import openpyxl

from sita_playwright_python_utils.config_loader import config_ini
from sita_playwright_python_utils.logger import Logger

logger = Logger(log_dir=config_ini.get("PATHS", "LOG_DIR"), log_name="framework environment_hooks", log_level=logging.INFO)


"""
@purpose This utility is to handle multiple operations of Excel file
"""


class ExcelUtils:
    def verify_file_exists(self, file_path: Path) -> Path:
        """
        Verify that the Excel file exists and return its absolute path.

        :param file_path: Path to the Excel file
        :return: Absolute Path of the verified Excel file
        :raises FileNotFoundError: If the file does not exist
        """
        path = Path(file_path)

        logger.log(
            f"Verifying Excel file at path: {path}"
        )

        if not path.exists():
            logger.log(
                f"Excel file not found at path: {path}"
            )
            raise FileNotFoundError(
                f"Excel file does not exist at path: {path}"
            )

        resolved_path = path.resolve()

        logger.log(
            f"Excel file verified successfully: {resolved_path}"
        )

        return resolved_path

    def get_excel_sheet(self, path_to_excel: Path, sheet_name=None):
        """
        Get worksheet from Excel file.
        """
        workbook = openpyxl.load_workbook(path_to_excel)

        if sheet_name:
            logger.log(f"Getting worksheet: {sheet_name}")
            return workbook[sheet_name]

        logger.log("Getting active worksheet")
        return workbook.active

    def get_cell_value(self, path_to_excel: Path, row: int, col: int, sheet_name=None):
        """
        Get value from a specific cell.
        """
        sheet = self.get_excel_sheet(path_to_excel, sheet_name)
        value = sheet.cell(row=row, column=col).value

        logger.log(f"Cell value at ({row}, {col}) is: {value}")
        return value

    def get_row_count(self, path_to_excel: Path, sheet_name=None):
        """
        Get total number of rows in the Excel sheet.
        """
        sheet = self.get_excel_sheet(path_to_excel, sheet_name)
        row_count = sheet.max_row

        logger.log(f"Total row count is: {row_count}")
        return row_count

    def get_column_count(self, path_to_excel: Path, sheet_name=None):
        """
        Get total number of columns in the Excel sheet.
        """
        sheet = self.get_excel_sheet(path_to_excel, sheet_name)
        col_count = sheet.max_column

        logger.log(f"Total column count is: {col_count}")
        return col_count

    def set_cell_value(self,path_to_excel: Path,row: int,col: int,value,sheet_name=None):
        """
        Set a specific cell value in Excel.
        """

        logger.log(f"Opening Excel file: {path_to_excel}")
        workbook = openpyxl.load_workbook(path_to_excel)

        if sheet_name:
            logger.log(f"Using worksheet: {sheet_name}")
            worksheet = workbook[sheet_name]
        else:
            logger.log("Using active worksheet")
            worksheet = workbook.active

        logger.log(f"Setting value '{value}' at cell ({row}, {col})")
        worksheet.cell(row=row, column=col).value = value

        workbook.save(path_to_excel)
        workbook.close()

        logger.log(f"Successfully saved value '{value}' at ({row}, {col})")

    def get_row_value(self,path_to_excel, row: int, sheet_name=None):
        """
         Method to get all columns in a row as a dictionary
         @param path_to_excel
         @param row
         @param sheet_name : Default value is None
         @return dictionary
        """
        row_value = {}

        logger.log("Getting column count")
        col_count = self.get_column_count(path_to_excel, sheet_name)

        logger.log("Setting row value in dictionary")
        for col_no in range(1, col_count + 1):
            col_header = self.get_cell_value(path_to_excel, 1, col_no, sheet_name)
            col_value = self.get_cell_value(path_to_excel, row, col_no, sheet_name)

            if col_header is None:
                continue

            row_value[col_header] = col_value

        logger.log("Returning row value as dictionary")
        logger.log(row_value)
        return row_value

    def get_column_values(self, path_to_excel: Path, col_index: int, sheet_name=None):
        """
        Return all values from a specific column as a list, excluding header row.
        """
        sheet = self.get_excel_sheet(path_to_excel, sheet_name)

        values = []
        for row in range(2, sheet.max_row + 1):
            cell_value = sheet.cell(row=row, column=col_index).value
            values.append(cell_value)

        logger.log(f"Values from column {col_index} in sheet '{sheet_name}' (excluding header): {values}")
        return values



