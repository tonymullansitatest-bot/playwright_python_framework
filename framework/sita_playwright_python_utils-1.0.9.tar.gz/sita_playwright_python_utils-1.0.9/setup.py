import setuptools

setuptools.setup(
    name="sita_playwright_python_utils",
    version="1.0.9",
    author="Nidhi Garg",
    description="Playwright and Behave utilities",
    packages=setuptools.find_packages(),
    install_requires=[],
    include_package_data=True,
)

