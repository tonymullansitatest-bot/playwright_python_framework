# Playwright Behave Framework

## Table of Contents
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Project Structure](#project-structure)
- [Gherkin Language](#gherkin-language)
- [Installation](#installation)
- [Configuration](#configuration)
  - [behave.ini](#behaveini)
  - [config.py](#configpy)
- [Running Tests](#running-tests)
- [Test Reports](#test-reports)
- [CI/CD Pipeline](#cicd-pipeline)
  - [.yml file](#yml-file)


## Overview
The **Playwright Behave Framework** is a test automation framework built with Python, Behave, and Playwright. It is designed for efficient, end-to-end testing on multiple browsers and platforms. The framework supports Behavior-Driven Development (BDD), empowering teams to collaborate by writing tests in Gherkin syntax—a natural language style easily understood by developers, testers, and business stakeholders.

Key Features:

- Cross-browser and cross-platform support.
- BDD test scenarios written in Gherkin syntax, facilitating collaboration among developers, testers, and business stakeholders.
- Debugging made easy with Playwright's video recording, tracing, and screenshots.
- Detailed test reports generated with Allure.
- Seamless integration with Azure DevOps for CI/CD pipelines.

Documentation for [Playwright](https://playwright.dev/), [Behave](https://behave.readthedocs.io/en/latest/), and [Allure](https://allurereport.org/docs/) can be found on their respective websites.
## Prerequisites
- Pip (Python package installer)
- Python 3.11+ (Download from https://www.python.org/downloads/)
- Azure DevOps account (for CI/CD pipeline)

**The project is using an internal library playwright_utils**

## Project structure
The framework has a modular and organized structure:
```
project-root/
├── src/
│   ├── features/
│   │   ├── environment.py
│   │   ├── steps/
│   │   │   └── step_definitions.py
│   │   └── example.feature
│   ├── pages/
│   │   └── pages.py
│   └── utils/
│       └── util_methods.py
├── config.py
├── behave.ini
├── requirements.txt
├── azure-pipelines.yml
└── README.md
```
**features/** <br>
Contains the `.feature` files that describe the test scenarios in Gherkin syntax. The `.feature`  files can reside in any subfolder under `./features` folder.<br>
Also includes the steps folder for step definitions and environment.py for global setup/teardown configurations. Behave need this file structure in order to run the tests.
 ```
 ├── features/
 │      ├── steps/
 │      ├── environment.py
 ```

**steps/** <br>
Contains the step definitions that implement the steps described in the feature files. These are written in Python and link the Gherkin steps to the actual test code.  

**environment.py**  <br>
A special module in Behave that allows you to set up and tear down test environments. It can be used to configure global settings, initialize resources, and clean up after tests.  

**pages/**  <br>
Contains page object models representing the application's web pages. Each model encapsulates page-specific methods and element interactions.

**utils/**  <br>
Contains utility methods that can be reused across different test scenarios.

**config.py**  <br>
Manages the configurations of the framework, such as browser settings, context settings, and paths for screenshots, videos, and traces.  

**behave.ini**  <br>
A configuration file for Behave that allows you to set default values for various settings, such as the browser, browser platform, and environment to use for the tests, some of these values can be overridden by passing them as command-line arguments.

**azure-pipelines.yml**  <br>
A configuration file for the Azure DevOps pipeline that defines the steps to build, test, and deploy the project. It integrates with the Azure DevOps services to automate the CI/CD process.

## Gherkin language
The framework contains examples of Gherkin syntax, check the `./gherkin_examples` folder for implementation examples.
```gherkin
Feature: The feature being tested
    A detailed description of the feature,
    which can span multiple lines.

    Background: Preconditions that must be met before any scenarios are executed.
        Given It can have multiple steps
        And It can have multiple steps

    Scenario: A description of the scenario being tested.
        Given Is used for preconditions (like login to the system or navigating to a page)
        When Is used for actions (like clicking a button or entering some data)
        Then Is used for the expected results (like verifying the output or the state of the system)

    Scenario: Another scenario description, with the option to use the "And" keyword for readability and clarity.
        Given Is used for preconditions (like login to the system or navigating to a page)
        And Is used for additional preconditions
        And Is used for additional preconditions
        When Is used for actions (like clicking a button or entering some data)
        And Is used for additional actions
        And Is used for additional actions
        And Is used for additional actions
        Then Is used for the expected results (like verifying the output or the state of the system)
        And Is used for additional expected results

    Scenario Outline: A description of a scenario outline, for each example from the table the scenario will be executed.
        Given Is used for preconditions (like login to the system or navigating to a page)
        When Is used for actions (like clicking a button or entering some data)
        Then Is used for the expected results (like verifying the output or the state of the system)

        Examples: Defines the data used in the scenario outline
            | parameter1 | parameter2 | parameter3 |
            | value1     | value4     | value7     |
            | value2     | value5     | value8     |
            | value3     | value6     | value9     |
```  

Steps can have parameters as simple parameter, text parameter or table parameter(check examples).

Features, scenario, and example tags are used to filter tests:
    A tag on a feature applies to all scenarios within it.
    A tag on a scenario applies only to that scenario.
    A tag on an example applies only to that specific example.


For more information about Gherkin syntax that Behave covers, check the official documentation:
https://behave.readthedocs.io/en/stable/gherkin.html
  




## Installation
1. Clone the repository:
    ```sh
    git clone https://sita-pse.visualstudio.com/QE/_git/POC_Playright_Behave
    cd <repository-directory>
    ```
2. Create and activate the virtual environment(Optional if the venv is already created):
    ```sh
   
    python -m venv venv
    venv\Scripts\activate 
    ```   
3. Install project dependencies:
    ```sh
    pip install -r requirements.txt
    ```
4. Install Playwright browsers:
    ```sh
    playwright install
    ```
   
## Configuration

### `behave.ini`
Configure the test settings in the `behave.ini` file:
```ini
[behave.userdata]
browser = chrome #set the browser to run the tests
browser_platform = desktop #set the platform to run the tests

execution_mode = Determines how the framework runs:
                # - execution_mode = # Blank - defaults to 'ui'
                # - execution_mode = # api - Run API tests only
                # - execution_mode = # hybrid - Run both UI and API for tests automatically

environment = dev #set the environment to run the tests
dev = https://environment_one.com/
prod = https://environment_two.com/
```
**The following parameters are mandatory in the `behave.ini` file: `browser`, `browser_platform`, `environment`, `execution_mode`, and the corresponding URLs for the environments.** <br>
Note: Command-line parameters take precedence over .ini configuration settings if both are provided.
```sh
behave environment=prod -D browser=firefox -D platform_browser=mobile 
```


### `config.py`
Configure the framework settings in the `config.py` file, **the following parameters are mandatory**:
```python
MOBILE_DEVICE_MODEL = "string" 
HEADLESS = boolean
VIEWPORT_WIDTH = 0  # Set the viewport width, if 0 it will use the screen width
VIEWPORT_HEIGHT = 0  # Set the viewport height, if 0 it will use the screen height
IGNORE_HTTP_ERRORS = boolean
ENABLE_RECORDING = boolean
SCREENSHOT_DIR = "path_to_directory"
SCREENSHOT_TYPE = "webp"  # Options: PNG, JPG
VIDEO_DIR = "path_to_directory"
ENABLE_TRACING = boolean
TRACE_DIR = "path_to_directory"
ENABLE_TRACING_SCREENSHOTS = boolean
ENABLE_TRACING_SNAPSHOTS = boolean
ENABLE_TRACING_SOURCES = boolean
SCREENSHOT_ALLURE_TYPE = AttachmentType.JPG  # Options: JPG, PNG using Allure AttachmentType
LOG_DIR = "path_to_directory"
MFA_ENABLED = boolean # For projects that use MFA automation login set this to true
MFA_STORAGE_STATE = "path_to_directory" # For projects that use MFA automation, this is where the storage state file is stored

```
All the parameters are pre-configured with default values in the framework and can be modified as needed.

## Running Tests
Run the tests using the following command:
1. Run all tests:
```sh
behave
```
2. Run tests with specific tags:
```sh
behave --tags=@tag_name  
behave --tags="@tag1,@tag2"
or 
behave --tags="@tag1 and @tag2"
```
Logical operators like `and`, `or`, and `not` can be used to combine tags.

3. Run tests with specific configurations:
```sh
behave --tags=<tag> -D environment=<env> -D browser=<browser> -D platform_browser=<platform_browser> 
behave --tags=@regression -D environment=dev -D browser=chrome -D platform_browser=desktop 
```
This command will override the values in the `behave.ini` file just for the current run.

## Test Reports
**To Setup Allure report on the local machine. <br><br>**
```sh
Download the latest Allure CLI from the official GitHub releases page:
https://github.com/allure-framework/allure2/releases
```sh
To Set Environment Variable:-
Open System Properties → Environment Variables → Set New Path
```sh
Verify Allure Installation
Open terminal or command prompt and run  → allure --version
```

To generate and serve the Allure report on the local machine, use the following commands.  <br>
To generate and save the report(a new generated report will overwrite the existing one):
```sh
allure generate allure-results -o allure-report --clean
```
To view the report in the browser:
```sh
allure serve allure-results
```

## CI/CD Pipeline
The project is integrated with Azure DevOps for CI/CD. The pipeline configuration can be found in the `azure-pipelines.yml` file.
- Parameters like `browser`, `environment`, `platform_browser` and `tags` can be passed from the Azure Pipelines UI to run the tests with specific configurations.

### .yml file
The azure-pipelines.yml file contains the pipeline configuration. The parameters are configurable, as example:
```yml
- name: environment
  displayName: Select environment
  type: string
  default: dev
  values:
    - dev
    - prod
```
If a new value is added to the `values` list like `qa` , then the `behave.ini` file should be updated with the new environment URL.




 